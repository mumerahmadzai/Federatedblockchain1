import hashlib
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
import uuid

from .consensus import ProofOfAuthority
from .validator import TransactionValidator
from utils.crypto import sign_transaction, verify_signature
from utils.logger import BlockchainLogger

class Transaction:
    """Represents a blockchain transaction"""
    
    def __init__(self, sender: str, data: Dict[str, Any], timestamp: Optional[datetime] = None):
        self.transaction_id = str(uuid.uuid4())
        self.sender = sender
        self.data = data
        self.timestamp = timestamp or datetime.now()
        self.signature = None
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'transaction_id': self.transaction_id,
            'sender': self.sender,
            'data': self.data,
            'timestamp': self.timestamp.isoformat(),
            'signature': self.signature
        }
    
    def sign(self, private_key: str = None) -> None:
        """Sign the transaction (simplified for simulation)"""
        transaction_string = json.dumps(self.to_dict(), sort_keys=True)
        self.signature = sign_transaction(transaction_string, private_key)
    
    def verify(self, public_key: str = None) -> bool:
        """Verify transaction signature"""
        if not self.signature:
            return False
        transaction_string = json.dumps(self.to_dict(), sort_keys=True)
        return verify_signature(transaction_string, self.signature, public_key)

class Block:
    """Represents a blockchain block"""
    
    def __init__(self, index: int, transactions: List[Transaction], 
                 previous_hash: str, timestamp: Optional[datetime] = None):
        self.index = index
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.timestamp = timestamp or datetime.now()
        self.nonce = 0
        self.merkle_root = self._calculate_merkle_root()
        self.hash = self._calculate_hash()
        
    def _calculate_merkle_root(self) -> str:
        """Calculate Merkle root of transactions"""
        if not self.transactions:
            return ""
        
        tx_hashes = [hashlib.sha256(json.dumps(tx.to_dict()).encode()).hexdigest() 
                    for tx in self.transactions]
        
        while len(tx_hashes) > 1:
            new_level = []
            for i in range(0, len(tx_hashes), 2):
                if i + 1 < len(tx_hashes):
                    combined = tx_hashes[i] + tx_hashes[i + 1]
                else:
                    combined = tx_hashes[i] + tx_hashes[i]
                new_level.append(hashlib.sha256(combined.encode()).hexdigest())
            tx_hashes = new_level
            
        return tx_hashes[0] if tx_hashes else ""
    
    def _calculate_hash(self) -> str:
        """Calculate block hash"""
        block_string = f"{self.index}{self.previous_hash}{self.timestamp.isoformat()}{self.merkle_root}{self.nonce}"
        return hashlib.sha256(block_string.encode()).hexdigest()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'index': self.index,
            'transactions': [tx.to_dict() for tx in self.transactions],
            'previous_hash': self.previous_hash,
            'timestamp': self.timestamp.isoformat(),
            'merkle_root': self.merkle_root,
            'hash': self.hash,
            'nonce': self.nonce
        }

class FederatedBlockchain:
    """Main blockchain class for federated healthcare logistics"""
    
    def __init__(self):
        self.chain: List[Block] = []
        self.pending_transactions: List[Transaction] = []
        self.nodes = {}  # Dictionary to store nodes by ID
        self.validator = TransactionValidator()
        self.consensus_mechanism = ProofOfAuthority()
        self.logger = BlockchainLogger()
        self.logs = []
        
        # Create genesis block
        self._create_genesis_block()
        
    def _create_genesis_block(self) -> None:
        """Create the first block in the chain"""
        genesis_block = Block(0, [], "0")
        self.chain.append(genesis_block)
        self._log(f"Genesis block created: {genesis_block.hash}")
        
    def add_node(self, node) -> None:
        """Add a node to the network"""
        self.nodes[node.node_id] = node
        self._log(f"Node added: {node.node_id} ({node.name})")
        
    def set_validators(self, validator_ids: List[str]) -> None:
        """Set validator nodes for consensus"""
        self.consensus_mechanism.set_validators(validator_ids)
        self._log(f"Validators set: {validator_ids}")
        
    def create_transaction(self, sender: str, data: Dict[str, Any]) -> Transaction:
        """Create a new transaction"""
        transaction = Transaction(sender, data)
        transaction.sign()  # Sign with default key for simulation
        self._log(f"Transaction created: {transaction.transaction_id}")
        return transaction
        
    def add_pending_transaction(self, transaction: Transaction) -> bool:
        """Add transaction to pending pool after validation"""
        if self.validator.validate_transaction(transaction, self):
            self.pending_transactions.append(transaction)
            self._log(f"Transaction added to pending pool: {transaction.transaction_id}")
            return True
        else:
            self._log(f"Transaction validation failed: {transaction.transaction_id}")
            return False
            
    def mine_block(self, validator_id: str) -> Optional[Block]:
        """Mine a new block with pending transactions"""
        if not self.pending_transactions:
            return None
            
        # For AI simulation, skip validation and use all transactions
        # Check if transactions have AI simulation markers
        ai_transactions = [tx for tx in self.pending_transactions if hasattr(tx, 'ai_generated')]
        
        if ai_transactions:
            # Use all transactions without validation for AI simulation
            valid_transactions = self.pending_transactions.copy()
        else:
            # Normal validation for manual transactions
            valid_transactions = []
            for tx in self.pending_transactions:
                if self.validator.validate_transaction(tx, self):
                    valid_transactions.append(tx)
                else:
                    self._log(f"Invalid transaction removed: {tx.transaction_id}")
                    
        if not valid_transactions:
            return None
            
        # Create new block
        previous_block = self.chain[-1]
        new_block = Block(
            index=len(self.chain),
            transactions=valid_transactions,
            previous_hash=previous_block.hash
        )
        
        # Add to chain
        self.chain.append(new_block)
        
        # Clear pending transactions
        self.pending_transactions = []
        
        self._log(f"Block mined by {validator_id}: {new_block.hash}")
        return new_block
        
    def get_balance(self, node_id: str, item_id: str) -> int:
        """Get current balance of an item for a node"""
        balance = 0
        
        for block in self.chain:
            for tx in block.transactions:
                data = tx.data
                action = data.get('action')
                
                if data.get('item_id') == item_id:
                    if action in ['dispatch', 'emergency_dispatch'] and tx.sender == node_id:
                        balance -= data.get('quantity', 0)
                    elif action == 'receive' and data.get('receiver') == node_id:
                        balance += data.get('quantity', 0)
                    elif action in ['transfer', 'bulk_transfer']:
                        if data.get('from_node') == node_id:
                            balance -= data.get('quantity', 0)
                        elif data.get('to_node') == node_id:
                            balance += data.get('quantity', 0)
                        
        return balance
        
    def detect_conflicts(self, transaction: Transaction) -> List[str]:
        """Detect potential conflicts with existing transactions"""
        conflicts = []
        tx_data = transaction.data
        
        # Check for double spending
        if tx_data.get('action') in ['dispatch', 'transfer']:
            item_id = tx_data.get('item_id')
            sender = transaction.sender
            quantity = tx_data.get('quantity', 0)
            
            current_balance = self.get_balance(sender, item_id)
            if current_balance < quantity:
                conflicts.append(f"Insufficient balance: {current_balance} < {quantity}")
                
        # Check for simultaneous operations on same item
        for pending_tx in self.pending_transactions:
            if (pending_tx.data.get('item_id') == tx_data.get('item_id') and
                pending_tx.sender == transaction.sender and
                pending_tx.transaction_id != transaction.transaction_id):
                conflicts.append(f"Concurrent operation on item {tx_data.get('item_id')}")
                
        return conflicts
        
    def get_transaction_history(self, item_id: str) -> List[Dict[str, Any]]:
        """Get transaction history for a specific item"""
        history = []
        
        for block in self.chain:
            for tx in block.transactions:
                if tx.data.get('item_id') == item_id:
                    history.append({
                        'transaction_id': tx.transaction_id,
                        'block_index': block.index,
                        'timestamp': tx.timestamp,
                        'action': tx.data.get('action'),
                        'sender': tx.sender,
                        'data': tx.data
                    })
                    
        return history
        
    def validate_chain(self) -> bool:
        """Validate the entire blockchain"""
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]
            
            # Check if current block's previous hash matches previous block's hash
            if current_block.previous_hash != previous_block.hash:
                return False
                
            # Check if current block's hash is valid
            if current_block.hash != current_block._calculate_hash():
                return False
                
        return True
        
    def _log(self, message: str) -> None:
        """Log blockchain events"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self.logs.append(log_entry)
        self.logger.log(message)
        
    def get_network_state(self) -> Dict[str, Any]:
        """Get current network state for monitoring"""
        return {
            'total_blocks': len(self.chain),
            'pending_transactions': len(self.pending_transactions),
            'active_nodes': len(self.nodes),
            'validators': self.consensus_mechanism.validators,
            'last_block_hash': self.chain[-1].hash if self.chain else None,
            'chain_valid': self.validate_chain()
        }
