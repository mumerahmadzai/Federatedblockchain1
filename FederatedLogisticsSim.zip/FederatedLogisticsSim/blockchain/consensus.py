from typing import List, Optional, Dict, Any
from datetime import datetime
import random
import hashlib

class ConsensusMessage:
    """Represents a consensus message between nodes"""
    
    def __init__(self, message_type: str, sender: str, data: Dict[str, Any]):
        self.message_type = message_type  # propose, vote, commit
        self.sender = sender
        self.data = data
        self.timestamp = datetime.now()
        self.message_id = hashlib.sha256(
            f"{message_type}{sender}{str(data)}{self.timestamp}".encode()
        ).hexdigest()[:16]

class ProofOfAuthority:
    """Proof of Authority consensus mechanism for federated blockchain"""
    
    def __init__(self):
        self.validators: List[str] = []
        self.current_validator: Optional[str] = None
        self.round = 0
        self.block_time = 10  # seconds
        self.last_block_time = datetime.now()
        self.pending_votes: Dict[str, List[str]] = {}  # block_hash -> list of validator votes
        self.consensus_threshold = 0.67  # 67% agreement required
        
    def set_validators(self, validator_ids: List[str]) -> None:
        """Set the list of authorized validators"""
        self.validators = validator_ids
        if validator_ids:
            self.current_validator = validator_ids[0]
            
    def get_current_validator(self) -> Optional[str]:
        """Get the current validator for this round"""
        if not self.validators:
            return None
            
        # Round-robin selection
        validator_index = self.round % len(self.validators)
        self.current_validator = self.validators[validator_index]
        return self.current_validator
        
    def can_propose_block(self, validator_id: str) -> bool:
        """Check if a validator can propose a block"""
        return validator_id in self.validators and validator_id == self.get_current_validator()
        
    def propose_block(self, blockchain) -> bool:
        """Propose a new block (simplified for simulation)"""
        if not self.validators:
            return False
            
        current_validator = self.get_current_validator()
        if not current_validator:
            return False
            
        # Check if enough time has passed
        time_since_last = (datetime.now() - self.last_block_time).seconds
        if time_since_last < self.block_time:
            return False
            
        # Mine block with current validator
        new_block = blockchain.mine_block(current_validator)
        
        if new_block:
            # Simulate consensus process
            consensus_reached = self._simulate_consensus(new_block)
            
            if consensus_reached:
                self.round += 1
                self.last_block_time = datetime.now()
                blockchain._log(f"Consensus reached for block {new_block.index}")
                return True
            else:
                # Remove the block if consensus failed
                blockchain.chain.pop()
                blockchain._log(f"Consensus failed for block {new_block.index}")
                return False
                
        return False
        
    def _simulate_consensus(self, block) -> bool:
        """Simulate consensus voting process"""
        if len(self.validators) < 2:
            return True  # Single validator auto-consensus
            
        # Simulate validator votes (in real implementation, this would be network communication)
        votes_for = 0
        votes_against = 0
        
        for validator in self.validators:
            # Simulate vote with high probability of agreement (90%)
            if random.random() < 0.9:
                votes_for += 1
            else:
                votes_against += 1
                
        total_votes = votes_for + votes_against
        agreement_ratio = votes_for / total_votes if total_votes > 0 else 0
        
        # Store voting results
        self.pending_votes[block.hash] = {
            'votes_for': votes_for,
            'votes_against': votes_against,
            'agreement_ratio': agreement_ratio,
            'validators': self.validators.copy()
        }
        
        return agreement_ratio >= self.consensus_threshold
        
    def validate_block_proposal(self, block, proposer: str) -> bool:
        """Validate a block proposal"""
        # Check if proposer is authorized
        if proposer not in self.validators:
            return False
            
        # Check if it's proposer's turn
        if proposer != self.get_current_validator():
            return False
            
        # Validate block structure
        if not block.hash or not block.previous_hash:
            return False
            
        # Check timestamp
        if block.timestamp > datetime.now():
            return False
            
        return True
        
    def get_consensus_state(self) -> Dict[str, Any]:
        """Get current consensus mechanism state"""
        return {
            'mechanism': 'Proof of Authority',
            'validators': self.validators,
            'current_validator': self.current_validator,
            'round': self.round,
            'block_time': self.block_time,
            'consensus_threshold': self.consensus_threshold,
            'last_block_time': self.last_block_time.isoformat() if self.last_block_time else None,
            'pending_votes': len(self.pending_votes)
        }
        
    def handle_validator_failure(self, failed_validator: str) -> None:
        """Handle validator node failure"""
        if failed_validator in self.validators:
            self.validators.remove(failed_validator)
            
            # Adjust current validator if needed
            if self.current_validator == failed_validator:
                self.current_validator = self.get_current_validator()
                
    def add_validator(self, validator_id: str) -> bool:
        """Add a new validator to the network"""
        if validator_id not in self.validators:
            self.validators.append(validator_id)
            return True
        return False
        
    def remove_validator(self, validator_id: str) -> bool:
        """Remove a validator from the network"""
        if validator_id in self.validators:
            self.validators.remove(validator_id)
            # Ensure we still have validators
            if not self.validators:
                return False
            # Update current validator if needed
            if self.current_validator == validator_id:
                self.current_validator = self.get_current_validator()
            return True
        return False

class PracticalByzantineFaultTolerance:
    """PBFT consensus implementation (simplified)"""
    
    def __init__(self):
        self.validators: List[str] = []
        self.phase = "prepare"  # prepare, commit, reply
        self.view = 0
        self.sequence_number = 0
        self.messages: Dict[str, List[ConsensusMessage]] = {
            'prepare': [],
            'commit': [],
            'reply': []
        }
        
    def set_validators(self, validator_ids: List[str]) -> None:
        self.validators = validator_ids
        
    def get_primary_validator(self) -> Optional[str]:
        """Get primary validator for current view"""
        if not self.validators:
            return None
        return self.validators[self.view % len(self.validators)]
        
    def can_tolerate_failures(self) -> int:
        """Calculate maximum failures the network can tolerate"""
        return (len(self.validators) - 1) // 3
        
    def initiate_consensus(self, block, blockchain) -> bool:
        """Initiate PBFT consensus process"""
        primary = self.get_primary_validator()
        if not primary:
            return False
            
        # Phase 1: Prepare
        prepare_msg = ConsensusMessage(
            "prepare",
            primary,
            {"block_hash": block.hash, "sequence": self.sequence_number}
        )
        
        self.messages['prepare'].append(prepare_msg)
        
        # Simulate validator responses
        prepare_responses = self._simulate_validator_responses("prepare", block.hash)
        
        if len(prepare_responses) >= 2 * self.can_tolerate_failures():
            # Phase 2: Commit
            commit_responses = self._simulate_validator_responses("commit", block.hash)
            
            if len(commit_responses) >= 2 * self.can_tolerate_failures():
                self.sequence_number += 1
                return True
                
        return False
        
    def _simulate_validator_responses(self, phase: str, block_hash: str) -> List[str]:
        """Simulate validator responses for a given phase"""
        responses = []
        
        for validator in self.validators:
            # Simulate high reliability (95% response rate)
            if random.random() < 0.95:
                msg = ConsensusMessage(
                    phase,
                    validator,
                    {"block_hash": block_hash, "agreement": True}
                )
                self.messages[phase].append(msg)
                responses.append(validator)
                
        return responses
        
    def get_consensus_state(self) -> Dict[str, Any]:
        return {
            'mechanism': 'Practical Byzantine Fault Tolerance',
            'validators': self.validators,
            'primary_validator': self.get_primary_validator(),
            'view': self.view,
            'sequence_number': self.sequence_number,
            'current_phase': self.phase,
            'max_failures': self.can_tolerate_failures()
        }
