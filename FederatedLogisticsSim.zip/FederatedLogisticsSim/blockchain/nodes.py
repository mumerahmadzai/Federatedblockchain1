from enum import Enum
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

class NodeType(Enum):
    """Types of healthcare nodes in the federated network"""
    HOSPITAL = "hospital"
    WAREHOUSE = "warehouse"
    CLINIC = "clinic"
    PHARMACY = "pharmacy"
    DISTRIBUTOR = "distributor"
    REGULATOR = "regulator"

class NodeStatus(Enum):
    """Node operational status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"
    SUSPENDED = "suspended"

class HealthcareNode:
    """Represents a healthcare node in the federated blockchain network"""
    
    def __init__(self, node_id: str, node_type: NodeType, name: str, location: str = ""):
        self.node_id = node_id
        self.node_type = node_type
        self.name = name
        self.location = location
        self.status = NodeStatus.ACTIVE
        self.joined_at = datetime.now()
        self.last_active = datetime.now()
        
        # Node capabilities based on type
        self.capabilities = self._initialize_capabilities()
        
        # Inventory tracking
        self.inventory: Dict[str, int] = {}
        
        # Transaction history
        self.transaction_history: List[str] = []
        
        # Node reputation score (0-100)
        self.reputation_score = 100
        
        # Network connections
        self.peers: List[str] = []
        
    def _initialize_capabilities(self) -> List[str]:
        """Initialize node capabilities based on type"""
        capabilities_map = {
            NodeType.HOSPITAL: ["dispatch", "receive", "validate", "emergency_request"],
            NodeType.WAREHOUSE: ["dispatch", "receive", "validate", "bulk_transfer", "inventory_audit"],
            NodeType.CLINIC: ["receive", "validate", "emergency_request"],
            NodeType.PHARMACY: ["dispatch", "receive", "validate", "prescription_fill"],
            NodeType.DISTRIBUTOR: ["dispatch", "receive", "transfer", "route_optimization"],
            NodeType.REGULATOR: ["validate", "audit", "compliance_check"]
        }
        return capabilities_map.get(self.node_type, ["receive", "validate"])
        
    def can_perform_action(self, action: str) -> bool:
        """Check if node can perform a specific action"""
        return action in self.capabilities
        
    def update_inventory(self, item_id: str, quantity_change: int) -> None:
        """Update node inventory"""
        if item_id not in self.inventory:
            self.inventory[item_id] = 0
        self.inventory[item_id] += quantity_change
        
        # Ensure inventory doesn't go negative
        if self.inventory[item_id] < 0:
            self.inventory[item_id] = 0
            
    def get_inventory_level(self, item_id: str) -> int:
        """Get current inventory level for an item"""
        return self.inventory.get(item_id, 0)
        
    def add_transaction(self, transaction_id: str) -> None:
        """Add transaction to node's history"""
        self.transaction_history.append(transaction_id)
        self.last_active = datetime.now()
        
    def update_reputation(self, score_change: int) -> None:
        """Update node reputation score"""
        self.reputation_score = max(0, min(100, self.reputation_score + score_change))
        
    def add_peer(self, peer_node_id: str) -> None:
        """Add a peer node connection"""
        if peer_node_id not in self.peers:
            self.peers.append(peer_node_id)
            
    def remove_peer(self, peer_node_id: str) -> None:
        """Remove a peer node connection"""
        if peer_node_id in self.peers:
            self.peers.remove(peer_node_id)
            
    def set_status(self, status: NodeStatus) -> None:
        """Set node operational status"""
        self.status = status
        if status == NodeStatus.ACTIVE:
            self.last_active = datetime.now()
            
    def get_node_info(self) -> Dict[str, Any]:
        """Get comprehensive node information"""
        return {
            'node_id': self.node_id,
            'name': self.name,
            'type': self.node_type.value,
            'location': self.location,
            'status': self.status.value,
            'capabilities': self.capabilities,
            'reputation_score': self.reputation_score,
            'joined_at': self.joined_at.isoformat(),
            'last_active': self.last_active.isoformat(),
            'total_transactions': len(self.transaction_history),
            'inventory_items': len(self.inventory),
            'peer_connections': len(self.peers)
        }
        
    def get_inventory_summary(self) -> Dict[str, Any]:
        """Get inventory summary"""
        total_items = sum(self.inventory.values())
        unique_items = len(self.inventory)
        
        return {
            'total_items': total_items,
            'unique_items': unique_items,
            'inventory': self.inventory.copy(),
            'low_stock_items': [
                item_id for item_id, quantity in self.inventory.items() 
                if quantity < 10  # Configurable threshold
            ]
        }
        
    def calculate_trust_score(self, other_node_id: str, blockchain) -> float:
        """Calculate trust score with another node based on transaction history"""
        if not blockchain:
            return 0.5  # Neutral trust
            
        successful_transactions = 0
        total_transactions = 0
        
        # Analyze transaction history with the other node
        for block in blockchain.chain:
            for tx in block.transactions:
                # Check if transaction involves both nodes
                tx_data = tx.data
                involves_both = False
                
                if tx.sender == self.node_id:
                    if (tx_data.get('destination') == other_node_id or
                        tx_data.get('receiver') == other_node_id or
                        tx_data.get('to_node') == other_node_id):
                        involves_both = True
                elif tx.sender == other_node_id:
                    if (tx_data.get('destination') == self.node_id or
                        tx_data.get('receiver') == self.node_id or
                        tx_data.get('to_node') == self.node_id):
                        involves_both = True
                        
                if involves_both:
                    total_transactions += 1
                    # Assume transaction was successful if it's in the blockchain
                    successful_transactions += 1
                    
        if total_transactions == 0:
            return 0.5  # No history, neutral trust
            
        return successful_transactions / total_transactions

class NetworkTopology:
    """Manages the network topology of healthcare nodes"""
    
    def __init__(self):
        self.nodes: Dict[str, HealthcareNode] = {}
        self.connections: Dict[str, List[str]] = {}
        
    def add_node(self, node: HealthcareNode) -> None:
        """Add a node to the network"""
        self.nodes[node.node_id] = node
        self.connections[node.node_id] = []
        
    def remove_node(self, node_id: str) -> None:
        """Remove a node from the network"""
        if node_id in self.nodes:
            # Remove all connections to this node
            for other_node_id in self.connections.get(node_id, []):
                if other_node_id in self.connections:
                    self.connections[other_node_id].remove(node_id)
                    self.nodes[other_node_id].remove_peer(node_id)
                    
            # Remove the node
            del self.nodes[node_id]
            del self.connections[node_id]
            
    def connect_nodes(self, node1_id: str, node2_id: str) -> bool:
        """Create a connection between two nodes"""
        if node1_id in self.nodes and node2_id in self.nodes:
            # Add bidirectional connection
            if node2_id not in self.connections[node1_id]:
                self.connections[node1_id].append(node2_id)
                self.nodes[node1_id].add_peer(node2_id)
                
            if node1_id not in self.connections[node2_id]:
                self.connections[node2_id].append(node1_id)
                self.nodes[node2_id].add_peer(node1_id)
                
            return True
        return False
        
    def disconnect_nodes(self, node1_id: str, node2_id: str) -> bool:
        """Remove connection between two nodes"""
        if node1_id in self.connections and node2_id in self.connections:
            if node2_id in self.connections[node1_id]:
                self.connections[node1_id].remove(node2_id)
                self.nodes[node1_id].remove_peer(node2_id)
                
            if node1_id in self.connections[node2_id]:
                self.connections[node2_id].remove(node1_id)
                self.nodes[node2_id].remove_peer(node1_id)
                
            return True
        return False
        
    def get_network_stats(self) -> Dict[str, Any]:
        """Get network topology statistics"""
        total_nodes = len(self.nodes)
        total_connections = sum(len(connections) for connections in self.connections.values()) // 2
        
        # Node type distribution
        type_distribution = {}
        for node in self.nodes.values():
            node_type = node.node_type.value
            type_distribution[node_type] = type_distribution.get(node_type, 0) + 1
            
        # Average connections per node
        avg_connections = total_connections * 2 / total_nodes if total_nodes > 0 else 0
        
        return {
            'total_nodes': total_nodes,
            'total_connections': total_connections,
            'average_connections_per_node': avg_connections,
            'node_type_distribution': type_distribution,
            'network_density': total_connections / (total_nodes * (total_nodes - 1) / 2) if total_nodes > 1 else 0
        }
        
    def find_shortest_path(self, start_node: str, end_node: str) -> Optional[List[str]]:
        """Find shortest path between two nodes using BFS"""
        if start_node not in self.nodes or end_node not in self.nodes:
            return None
            
        if start_node == end_node:
            return [start_node]
            
        visited = set()
        queue = [(start_node, [start_node])]
        
        while queue:
            current_node, path = queue.pop(0)
            
            if current_node in visited:
                continue
                
            visited.add(current_node)
            
            for neighbor in self.connections.get(current_node, []):
                if neighbor == end_node:
                    return path + [neighbor]
                    
                if neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))
                    
        return None  # No path found
