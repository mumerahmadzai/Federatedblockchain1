"""
Drug Authentication and Anti-Counterfeiting Module
Provides advanced verification and authenticity tracking for pharmaceutical products
"""

import hashlib
import random
import time
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta

class DrugAuthenticator:
    """Handles drug authentication and anti-counterfeiting measures"""
    
    def __init__(self):
        self.batch_registry = {}
        self.manufacturer_keys = {}
        self.suspicious_patterns = []
        
    def generate_drug_fingerprint(self, drug_data: Dict) -> str:
        """Generate unique cryptographic fingerprint for drug batch"""
        # Combine critical drug attributes
        fingerprint_data = f"{drug_data.get('manufacturer', '')}" \
                          f"{drug_data.get('batch_number', '')}" \
                          f"{drug_data.get('production_date', '')}" \
                          f"{drug_data.get('active_ingredients', '')}" \
                          f"{drug_data.get('ndc_number', '')}"
        
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()[:16]
    
    def register_authentic_batch(self, manufacturer: str, drug_data: Dict) -> Dict:
        """Register a new authentic drug batch"""
        batch_id = f"BATCH_{random.randint(100000, 999999)}"
        fingerprint = self.generate_drug_fingerprint(drug_data)
        
        batch_info = {
            'batch_id': batch_id,
            'manufacturer': manufacturer,
            'fingerprint': fingerprint,
            'registration_time': datetime.now(),
            'drug_data': drug_data,
            'verification_count': 0,
            'status': 'authentic'
        }
        
        self.batch_registry[batch_id] = batch_info
        return batch_info
    
    def verify_drug_authenticity(self, claimed_batch_id: str, drug_sample: Dict) -> Dict:
        """Verify if a drug sample matches authentic registered batch"""
        if claimed_batch_id not in self.batch_registry:
            return {
                'authentic': False,
                'reason': 'Batch ID not found in registry',
                'risk_level': 'HIGH',
                'action': 'QUARANTINE'
            }
        
        registered_batch = self.batch_registry[claimed_batch_id]
        sample_fingerprint = self.generate_drug_fingerprint(drug_sample)
        
        if sample_fingerprint == registered_batch['fingerprint']:
            registered_batch['verification_count'] += 1
            return {
                'authentic': True,
                'batch_id': claimed_batch_id,
                'manufacturer': registered_batch['manufacturer'],
                'verification_count': registered_batch['verification_count'],
                'risk_level': 'LOW'
            }
        else:
            # Potential counterfeit detected
            self._log_suspicious_activity(claimed_batch_id, drug_sample, sample_fingerprint)
            return {
                'authentic': False,
                'reason': 'Fingerprint mismatch - potential counterfeit',
                'risk_level': 'CRITICAL',
                'action': 'IMMEDIATE_INVESTIGATION'
            }
    
    def _log_suspicious_activity(self, batch_id: str, drug_sample: Dict, fingerprint: str):
        """Log suspicious authentication attempts"""
        suspicious_event = {
            'timestamp': datetime.now(),
            'claimed_batch_id': batch_id,
            'sample_fingerprint': fingerprint,
            'sample_data': drug_sample,
            'severity': 'HIGH'
        }
        self.suspicious_patterns.append(suspicious_event)
    
    def get_authentication_stats(self) -> Dict:
        """Get authentication statistics and alerts"""
        total_batches = len(self.batch_registry)
        total_verifications = sum(batch['verification_count'] for batch in self.batch_registry.values())
        suspicious_count = len(self.suspicious_patterns)
        
        return {
            'total_registered_batches': total_batches,
            'total_verifications': total_verifications,
            'suspicious_activities': suspicious_count,
            'counterfeit_detection_rate': (suspicious_count / max(total_verifications, 1)) * 100
        }

class RegulatoryCompliance:
    """Ensures compliance with pharmaceutical regulations"""
    
    def __init__(self):
        self.compliance_rules = {
            'FDA_DSCSA': {
                'requires_serialization': True,
                'traceability_required': True,
                'verification_events': ['manufacturing', 'wholesale', 'dispensing']
            },
            'EU_FMD': {
                'requires_unique_identifier': True,
                'anti_tampering_required': True,
                'decommissioning_required': True
            },
            'WHO_GDP': {
                'temperature_monitoring': True,
                'quality_assurance': True,
                'documentation_required': True
            }
        }
        
    def check_compliance(self, transaction_data: Dict, regulation: str) -> Dict:
        """Check if transaction meets regulatory requirements"""
        if regulation not in self.compliance_rules:
            return {'compliant': False, 'reason': 'Unknown regulation'}
        
        rules = self.compliance_rules[regulation]
        compliance_issues = []
        
        # Check each requirement
        for requirement, required in rules.items():
            if required and not self._check_requirement(transaction_data, requirement):
                compliance_issues.append(requirement)
        
        return {
            'compliant': len(compliance_issues) == 0,
            'regulation': regulation,
            'issues': compliance_issues,
            'compliance_score': max(0, 100 - (len(compliance_issues) * 20))
        }
    
    def _check_requirement(self, data: Dict, requirement: str) -> bool:
        """Check if specific requirement is met"""
        requirement_checks = {
            'requires_serialization': lambda d: 'serial_number' in d or 'batch_id' in d,
            'traceability_required': lambda d: 'origin' in d and 'destination' in d,
            'temperature_monitoring': lambda d: 'temperature' in d,
            'requires_unique_identifier': lambda d: 'unique_id' in d or 'ndc_number' in d,
            'anti_tampering_required': lambda d: 'tamper_evidence' in d,
            'quality_assurance': lambda d: 'quality_check' in d
        }
        
        check_func = requirement_checks.get(requirement, lambda d: False)
        return check_func(data)

class AdvancedAnalytics:
    """Advanced analytics for supply chain optimization"""
    
    def __init__(self):
        self.prediction_models = {}
        self.anomaly_threshold = 0.85
        
    def predict_demand(self, historical_data: List[Dict], drug_id: str) -> Dict:
        """Predict future demand using simple trend analysis"""
        if len(historical_data) < 3:
            return {'prediction': 'insufficient_data', 'confidence': 0}
        
        # Simple trend calculation
        recent_quantities = [d.get('quantity', 0) for d in historical_data[-5:]]
        avg_demand = sum(recent_quantities) / len(recent_quantities)
        
        # Calculate trend
        if len(recent_quantities) >= 2:
            trend = (recent_quantities[-1] - recent_quantities[0]) / len(recent_quantities)
        else:
            trend = 0
        
        predicted_demand = max(0, avg_demand + trend)
        
        # Calculate confidence based on data consistency
        variance = sum((q - avg_demand) ** 2 for q in recent_quantities) / len(recent_quantities)
        confidence = max(0.1, 1 - (variance / (avg_demand + 1)))
        
        return {
            'drug_id': drug_id,
            'predicted_demand': round(predicted_demand),
            'confidence': round(confidence, 2),
            'trend': 'increasing' if trend > 0 else 'decreasing' if trend < 0 else 'stable',
            'recommendation': self._generate_recommendation(predicted_demand, trend)
        }
    
    def detect_supply_anomalies(self, transaction_data: List[Dict]) -> List[Dict]:
        """Detect unusual patterns in supply chain transactions"""
        anomalies = []
        
        if len(transaction_data) < 10:
            return anomalies
        
        # Analyze transaction patterns
        quantities = [t.get('quantity', 0) for t in transaction_data]
        avg_quantity = sum(quantities) / len(quantities)
        
        for i, transaction in enumerate(transaction_data):
            quantity = transaction.get('quantity', 0)
            
            # Check for unusual quantity spikes
            if quantity > avg_quantity * 3:
                anomalies.append({
                    'type': 'quantity_spike',
                    'transaction_id': transaction.get('transaction_id', f'tx_{i}'),
                    'severity': 'medium',
                    'description': f'Unusually large quantity: {quantity} vs avg {avg_quantity:.1f}'
                })
            
            # Check for unusual timing patterns
            if 'timestamp' in transaction:
                hour = transaction['timestamp'].hour
                if hour < 6 or hour > 22:  # Outside normal business hours
                    anomalies.append({
                        'type': 'unusual_timing',
                        'transaction_id': transaction.get('transaction_id', f'tx_{i}'),
                        'severity': 'low',
                        'description': f'Transaction at unusual hour: {hour}:00'
                    })
        
        return anomalies
    
    def _generate_recommendation(self, predicted_demand: float, trend: float) -> str:
        """Generate supply chain recommendations"""
        if predicted_demand > 100 and trend > 0:
            return "Consider increasing safety stock levels"
        elif predicted_demand < 20:
            return "Review inventory levels to prevent overstock"
        elif trend > 5:
            return "Monitor for potential supply shortage"
        else:
            return "Current supply levels appear adequate"

class SmartAlerts:
    """Intelligent alerting system for supply chain events"""
    
    def __init__(self):
        self.alert_rules = {}
        self.alert_history = []
        
    def configure_alert_rule(self, rule_name: str, conditions: Dict, severity: str):
        """Configure custom alert rules"""
        self.alert_rules[rule_name] = {
            'conditions': conditions,
            'severity': severity,
            'enabled': True,
            'trigger_count': 0
        }
    
    def evaluate_alerts(self, transaction_data: Dict) -> List[Dict]:
        """Evaluate transaction against all alert rules"""
        triggered_alerts = []
        
        for rule_name, rule in self.alert_rules.items():
            if not rule['enabled']:
                continue
                
            if self._check_conditions(transaction_data, rule['conditions']):
                alert = {
                    'rule_name': rule_name,
                    'severity': rule['severity'],
                    'timestamp': datetime.now(),
                    'transaction_id': transaction_data.get('transaction_id', 'unknown'),
                    'message': self._generate_alert_message(rule_name, transaction_data)
                }
                
                triggered_alerts.append(alert)
                rule['trigger_count'] += 1
                self.alert_history.append(alert)
        
        return triggered_alerts
    
    def _check_conditions(self, data: Dict, conditions: Dict) -> bool:
        """Check if alert conditions are met"""
        for field, condition in conditions.items():
            if field not in data:
                continue
                
            value = data[field]
            
            if 'min' in condition and value < condition['min']:
                return True
            if 'max' in condition and value > condition['max']:
                return True
            if 'equals' in condition and value == condition['equals']:
                return True
            if 'contains' in condition and condition['contains'] in str(value):
                return True
        
        return False
    
    def _generate_alert_message(self, rule_name: str, data: Dict) -> str:
        """Generate human-readable alert message"""
        messages = {
            'temperature_violation': f"Temperature outside safe range: {data.get('temperature', 'N/A')}°C",
            'large_quantity': f"Large quantity transaction: {data.get('quantity', 'N/A')} units",
            'emergency_dispatch': f"Emergency dispatch initiated from {data.get('sender', 'unknown')}",
            'expired_item': f"Expired item detected: {data.get('item_id', 'unknown')}"
        }
        
        return messages.get(rule_name, f"Alert triggered for rule: {rule_name}")