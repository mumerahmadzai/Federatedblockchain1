from typing import Dict, Any, Tuple, List

class LogisticsContract:
    """Smart contract for healthcare logistics operations"""
    
    def __init__(self):
        self.contract_state = {
            'total_executions': 0,
            'successful_executions': 0,
            'failed_executions': 0,
            'execution_history': []
        }
    
    def execute_transaction(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute a logistics transaction through the smart contract"""
        try:
            self.contract_state['total_executions'] += 1
            
            action = data.get('action', '').lower()
            
            if action == 'dispatch':
                success, message = self._execute_dispatch(data, blockchain)
            elif action == 'receive':
                success, message = self._execute_receive(data, blockchain)
            elif action == 'validate':
                success, message = self._execute_validate(data, blockchain)
            elif action == 'transfer':
                success, message = self._execute_transfer(data, blockchain)
            elif action == 'emergency_dispatch':
                success, message = self._execute_emergency_dispatch(data, blockchain)
            elif action == 'bulk_transfer':
                success, message = self._execute_bulk_transfer(data, blockchain)
            elif action == 'temperature_track':
                success, message = self._execute_temperature_track(data, blockchain)
            else:
                success, message = False, f"Unknown action: {action}"
            
            if success:
                self.contract_state['successful_executions'] += 1
            else:
                self.contract_state['failed_executions'] += 1
                
            self.contract_state['execution_history'].append({
                'action': action,
                'success': success,
                'message': message,
                'data': data
            })
            
            return success, message
            
        except Exception as e:
            self.contract_state['failed_executions'] += 1
            return False, f"Contract execution error: {str(e)}"
    
    def _execute_dispatch(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute dispatch operation"""
        required_fields = ['item_id', 'quantity', 'sender', 'destination']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        item_id = data['item_id']
        quantity = data['quantity']
        sender = data['sender']
        destination = data['destination']
        
        # Validate quantity
        if quantity <= 0:
            return False, "Quantity must be positive"
            
        # Check if destination node exists
        if destination not in blockchain.nodes:
            return False, f"Destination node not found: {destination}"
            
        # Check sender balance and allow new item introduction
        current_balance = blockchain.get_balance(sender, item_id)
        
        # Check if this item exists in the blockchain at all
        item_exists = any(
            tx.data.get('item_id') == item_id
            for block in blockchain.chain
            for tx in block.transactions
        )
        
        if current_balance < quantity:
            # Allow dispatch if this is a new item being introduced or if sender is a warehouse/distributor
            sender_node = blockchain.nodes.get(sender)
            
            if not item_exists:
                # New item introduction - always allowed
                pass
            elif sender_node and sender_node.node_type.value in ['warehouse', 'distributor']:
                # Warehouses and distributors can create inventory
                pass
            else:
                return False, f"Insufficient inventory: {current_balance} available, {quantity} requested"
                
        return True, "Dispatch operation validated"
    
    def _execute_receive(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute receive operation"""
        required_fields = ['item_id', 'quantity', 'source', 'receiver']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        item_id = data['item_id']
        quantity = data['quantity']
        source = data['source']
        receiver = data['receiver']
        
        # Validate quantity
        if quantity <= 0:
            return False, "Quantity must be positive"
            
        # Check if source node exists
        if source not in blockchain.nodes:
            return False, f"Source node not found: {source}"
            
        # For receive transactions, we don't check source balance
        # The receiving node is recording that they received items
        # Source validation would be done at dispatch time
            
        return True, "Receive operation validated"
    
    def _execute_validate(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute validation operation"""
        required_fields = ['item_id', 'result', 'validator']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        item_id = data['item_id']
        result = data['result']
        validator = data['validator']
        
        # Check if validator node exists
        if validator not in blockchain.nodes:
            return False, f"Validator node not found: {validator}"
            
        # Check if validator can perform validation
        validator_node = blockchain.nodes.get(validator)
        if validator_node and not validator_node.can_perform_action('validate'):
            return False, f"Node {validator} is not authorized to perform validation"
            
        # Validate result value
        valid_results = ['passed', 'failed', 'pending']
        if result not in valid_results:
            return False, f"Invalid validation result: {result}. Must be one of {valid_results}"
            
        return True, "Validation operation completed"
    
    def _execute_transfer(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute transfer operation"""
        required_fields = ['item_id', 'quantity', 'from_node', 'to_node']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        item_id = data['item_id']
        quantity = data['quantity']
        from_node = data['from_node']
        to_node = data['to_node']
        
        # Validate quantity
        if quantity <= 0:
            return False, "Quantity must be positive"
            
        # Check if both nodes exist
        if from_node not in blockchain.nodes:
            return False, f"Source node not found: {from_node}"
        if to_node not in blockchain.nodes:
            return False, f"Destination node not found: {to_node}"
            
        # Check source balance
        source_balance = blockchain.get_balance(from_node, item_id)
        if source_balance < quantity:
            return False, f"Insufficient inventory: {source_balance} available, {quantity} requested"
            
        return True, "Transfer operation validated"
    
    def _execute_emergency_dispatch(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute emergency dispatch operation with high priority"""
        required_fields = ['item_id', 'quantity', 'sender', 'destination', 'priority']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        # Emergency dispatches have relaxed validation
        item_id = data['item_id']
        quantity = data['quantity']
        sender = data['sender']
        destination = data['destination']
        priority = data['priority']
        
        # Validate quantity
        if quantity <= 0:
            return False, "Quantity must be positive"
            
        # Check if destination node exists
        if destination not in blockchain.nodes:
            return False, f"Destination node not found: {destination}"
            
        # Emergency dispatches allow negative balance for critical situations
        if priority == 'critical':
            return True, "Emergency dispatch authorized for critical situation"
            
        return True, "Emergency dispatch operation validated"
    
    def _execute_bulk_transfer(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute bulk transfer operation"""
        required_fields = ['transfers', 'sender']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        transfers = data['transfers']
        sender = data['sender']
        
        if not isinstance(transfers, list) or len(transfers) == 0:
            return False, "Transfers must be a non-empty list"
            
        # Validate each transfer in the bulk
        for i, transfer in enumerate(transfers):
            if not all(field in transfer for field in ['item_id', 'quantity', 'destination']):
                return False, f"Transfer {i+1} missing required fields"
                
            if transfer['quantity'] <= 0:
                return False, f"Transfer {i+1} has invalid quantity"
                
            if transfer['destination'] not in blockchain.nodes:
                return False, f"Transfer {i+1} destination not found: {transfer['destination']}"
                
        return True, "Bulk transfer operation validated"
    
    def _execute_temperature_track(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Execute temperature tracking operation"""
        required_fields = ['item_id', 'temperature', 'timestamp', 'tracker']
        for field in required_fields:
            if field not in data:
                return False, f"Missing required field: {field}"
                
        item_id = data['item_id']
        temperature = data['temperature']
        tracker = data['tracker']
        
        # Check if tracker node exists
        if tracker not in blockchain.nodes:
            return False, f"Tracker node not found: {tracker}"
            
        # Validate temperature range (assuming Celsius)
        if not isinstance(temperature, (int, float)):
            return False, "Temperature must be a number"
            
        if temperature < -273.15:  # Absolute zero
            return False, "Temperature cannot be below absolute zero"
            
        return True, "Temperature tracking operation validated"
    
    def get_contract_state(self) -> Dict[str, Any]:
        """Get current contract state"""
        return self.contract_state.copy()
    
    def get_item_lifecycle(self, item_id: str, blockchain) -> List[Dict[str, Any]]:
        """Get the complete lifecycle of an item"""
        lifecycle = []
        
        for block in blockchain.chain:
            for tx in block.transactions:
                if tx.data.get('item_id') == item_id:
                    lifecycle.append({
                        'timestamp': tx.timestamp,
                        'action': tx.data.get('action'),
                        'sender': tx.sender,
                        'data': tx.data,
                        'block_index': block.index
                    })
        
        return sorted(lifecycle, key=lambda x: x['timestamp'])
    
    def audit_compliance(self, blockchain) -> Dict[str, Any]:
        """Perform compliance audit on all transactions"""
        audit_results = {
            'total_transactions': 0,
            'compliant_transactions': 0,
            'non_compliant_transactions': 0,
            'compliance_issues': []
        }
        
        for block in blockchain.chain:
            for tx in block.transactions:
                audit_results['total_transactions'] += 1
                
                # Check basic compliance
                if not tx.data.get('action'):
                    audit_results['non_compliant_transactions'] += 1
                    audit_results['compliance_issues'].append({
                        'transaction_id': tx.transaction_id,
                        'issue': 'Missing action field'
                    })
                else:
                    audit_results['compliant_transactions'] += 1
        
        return audit_results

class SupplyChainContract(LogisticsContract):
    """Extended contract for supply chain specific operations"""
    
    def __init__(self):
        super().__init__()
        self.cold_chain_data = {}
    
    def track_temperature(self, data: Dict[str, Any], blockchain) -> Tuple[bool, str]:
        """Track temperature-sensitive items"""
        success, message = self._execute_temperature_track(data, blockchain)
        
        if success:
            item_id = data['item_id']
            if item_id not in self.cold_chain_data:
                self.cold_chain_data[item_id] = []
            
            self.cold_chain_data[item_id].append({
                'temperature': data['temperature'],
                'timestamp': data['timestamp'],
                'tracker': data['tracker']
            })
        
        return success, message
    
    def verify_cold_chain(self, item_id: str, blockchain) -> Dict[str, Any]:
        """Verify cold chain compliance for an item"""
        if item_id not in self.cold_chain_data:
            return {
                'compliant': False,
                'reason': 'No temperature data available'
            }
        
        temperature_data = self.cold_chain_data[item_id]
        
        # Check if all temperatures are within acceptable range (2-8°C for vaccines)
        acceptable_min = 2.0
        acceptable_max = 8.0
        
        violations = []
        for reading in temperature_data:
            temp = reading['temperature']
            if temp < acceptable_min or temp > acceptable_max:
                violations.append({
                    'temperature': temp,
                    'timestamp': reading['timestamp'],
                    'tracker': reading['tracker']
                })
        
        return {
            'compliant': len(violations) == 0,
            'violations': violations,
            'total_readings': len(temperature_data)
        }