from typing import Dict, Any, List, Tuple
from datetime import datetime, timedelta
import re

class TransactionValidator:
    """Validates blockchain transactions for healthcare logistics"""
    
    def __init__(self):
        self.validation_rules = self._initialize_validation_rules()
        self.item_id_pattern = re.compile(r'^[A-Z0-9_]{1,50}$')  # Item ID format
        
    def _initialize_validation_rules(self) -> Dict[str, Any]:
        """Initialize validation rules for different transaction types"""
        return {
            'dispatch': {
                'required_fields': ['item_id', 'quantity', 'destination', 'sender'],
                'numeric_fields': ['quantity'],
                'positive_fields': ['quantity'],
                'max_quantity': 10000,
                'expiry_check': True
            },
            'receive': {
                'required_fields': ['item_id', 'quantity', 'source', 'receiver'],
                'numeric_fields': ['quantity'],
                'positive_fields': ['quantity'],
                'max_quantity': 10000,
                'match_dispatch': True
            },
            'validate': {
                'required_fields': ['item_id', 'result', 'validator'],
                'valid_results': ['passed', 'failed', 'pending'],
                'validator_authority': True
            },
            'transfer': {
                'required_fields': ['item_id', 'from_node', 'to_node', 'initiator'],
                'numeric_fields': ['quantity'],
                'positive_fields': ['quantity'],
                'balance_check': True,
                'different_nodes': True
            },
            'emergency_dispatch': {
                'required_fields': ['item_id', 'quantity', 'destination', 'sender', 'priority'],
                'numeric_fields': ['quantity'],
                'positive_fields': ['quantity'],
                'max_quantity': 50000,  # Higher limit for emergencies
                'valid_priorities': ['critical', 'high', 'urgent'],
                'bypass_balance': True  # Emergency dispatches can bypass balance checks
            },
            'bulk_transfer': {
                'required_fields': ['item_id', 'from_node', 'to_node', 'initiator'],
                'numeric_fields': ['quantity'],
                'positive_fields': ['quantity'],
                'min_quantity': 100,  # Minimum for bulk operations
                'balance_check': True
            },
            'temperature_track': {
                'required_fields': ['item_id', 'temperature', 'threshold_min', 'threshold_max', 'recorder'],
                'numeric_fields': ['temperature', 'threshold_min', 'threshold_max'],
                'temperature_validation': True
            }
        }
        
    def validate_transaction(self, transaction, blockchain) -> bool:
        """Main transaction validation method"""
        try:
            # Basic transaction structure validation
            if not self._validate_transaction_structure(transaction):
                return False
                
            # Action-specific validation
            action = transaction.data.get('action')
            if action not in self.validation_rules:
                return False
                
            # Apply validation rules for the action
            if not self._apply_validation_rules(transaction, action, blockchain):
                return False
                
            # Business logic validation
            if not self._validate_business_logic(transaction, blockchain):
                return False
                
            # Security validation
            if not self._validate_security(transaction, blockchain):
                return False
                
            return True
            
        except Exception as e:
            print(f"Validation error for transaction {transaction.transaction_id}: {str(e)}")
            print(f"Transaction data: {transaction.data}")
            return False
            
    def _validate_transaction_structure(self, transaction) -> bool:
        """Validate basic transaction structure"""
        if not hasattr(transaction, 'transaction_id') or not transaction.transaction_id:
            return False
            
        if not hasattr(transaction, 'sender') or not transaction.sender:
            return False
            
        if not hasattr(transaction, 'data') or not isinstance(transaction.data, dict):
            return False
            
        if not hasattr(transaction, 'timestamp') or not transaction.timestamp:
            return False
            
        # Check timestamp is not in the future
        if transaction.timestamp > datetime.now() + timedelta(minutes=5):
            return False
            
        return True
        
    def _apply_validation_rules(self, transaction, action: str, blockchain) -> bool:
        """Apply action-specific validation rules"""
        rules = self.validation_rules[action]
        data = transaction.data
        
        # Check required fields
        for field in rules.get('required_fields', []):
            if field not in data or data[field] is None or data[field] == '':
                print(f"Validation failed: Missing required field '{field}' for action '{action}'")
                print(f"Available fields: {list(data.keys())}")
                return False
                
        # Validate numeric fields
        for field in rules.get('numeric_fields', []):
            if field in data:
                try:
                    value = float(data[field])
                    if field in rules.get('positive_fields', []) and value <= 0:
                        return False
                    if field == 'quantity' and value > rules.get('max_quantity', 10000):
                        return False
                except (ValueError, TypeError):
                    return False
                    
        # Validate item ID format
        if 'item_id' in data:
            if not self.item_id_pattern.match(str(data['item_id'])):
                return False
                
        # Action-specific validations
        if action == 'validate':
            result = data.get('result')
            if result not in rules.get('valid_results', []):
                return False
                
        if action == 'transfer':
            if rules.get('different_nodes'):
                if data.get('from_node') == data.get('to_node'):
                    return False
                    
        if action == 'emergency_dispatch':
            priority = data.get('priority')
            if priority not in rules.get('valid_priorities', []):
                return False
                
        if action == 'bulk_transfer':
            quantity = data.get('quantity', 0)
            if quantity < rules.get('min_quantity', 100):
                return False
                
        if action == 'temperature_track':
            if rules.get('temperature_validation'):
                min_temp = data.get('threshold_min')
                max_temp = data.get('threshold_max')
                if min_temp is not None and max_temp is not None and min_temp >= max_temp:
                    return False
                    
        return True
        
    def _validate_business_logic(self, transaction, blockchain) -> bool:
        """Validate business logic rules"""
        data = transaction.data
        action = data.get('action')
        
        # Validate node existence
        if not self._validate_node_existence(transaction, blockchain):
            return False
            
        # Validate node capabilities
        if not self._validate_node_capabilities(transaction, blockchain):
            return False
            
        # Action-specific business logic
        if action == 'dispatch':
            return self._validate_dispatch_logic(transaction, blockchain)
        elif action == 'receive':
            return self._validate_receive_logic(transaction, blockchain)
        elif action == 'transfer':
            return self._validate_transfer_logic(transaction, blockchain)
        elif action == 'validate':
            return self._validate_validation_logic(transaction, blockchain)
        elif action == 'emergency_dispatch':
            return self._validate_emergency_dispatch_logic(transaction, blockchain)
        elif action == 'bulk_transfer':
            return self._validate_bulk_transfer_logic(transaction, blockchain)
        elif action == 'temperature_track':
            return self._validate_temperature_track_logic(transaction, blockchain)
            
        return True
        
    def _validate_node_existence(self, transaction, blockchain) -> bool:
        """Validate that all referenced nodes exist"""
        data = transaction.data
        node_fields = ['sender', 'destination', 'source', 'receiver', 'from_node', 'to_node', 'validator']
        
        existing_nodes = set(blockchain.nodes.keys())
        
        for field in node_fields:
            if field in data and data[field]:
                if data[field] not in existing_nodes:
                    return False
                    
        # Also check transaction sender
        if transaction.sender not in existing_nodes:
            return False
            
        return True
        
    def _validate_node_capabilities(self, transaction, blockchain) -> bool:
        """Validate that nodes can perform requested actions"""
        action = transaction.data.get('action')
        sender_node = blockchain.nodes.get(transaction.sender)
        
        if not sender_node:
            return False
            
        return sender_node.can_perform_action(action)
        
    def _validate_dispatch_logic(self, transaction, blockchain) -> bool:
        """Validate dispatch-specific business logic"""
        data = transaction.data
        sender = transaction.sender
        item_id = data.get('item_id')
        quantity = data.get('quantity', 0)
        
        # Check inventory levels (simplified - assume some initial stock)
        current_balance = blockchain.get_balance(sender, item_id)
        
        # For first-time dispatch, allow it (simulate initial inventory)
        if current_balance == 0:
            # Check if this is genuinely the first dispatch for this item from this sender
            first_dispatch = True
            for block in blockchain.chain:
                for tx in block.transactions:
                    if (tx.data.get('action') == 'dispatch' and 
                        tx.sender == sender and 
                        tx.data.get('item_id') == item_id):
                        first_dispatch = False
                        break
                if not first_dispatch:
                    break
                    
            if not first_dispatch and current_balance < quantity:
                return False
        elif current_balance < quantity:
            return False
            
        return True
        
    def _validate_receive_logic(self, transaction, blockchain) -> bool:
        """Validate receive-specific business logic"""
        data = transaction.data
        item_id = data.get('item_id')
        quantity = data.get('quantity', 0)
        source = data.get('source')
        receiver = data.get('receiver')
        
        # Check if there's a corresponding dispatch (optional for simulation)
        # In a real system, this would be mandatory
        return True
        
    def _validate_transfer_logic(self, transaction, blockchain) -> bool:
        """Validate transfer-specific business logic"""
        data = transaction.data
        from_node = data.get('from_node')
        item_id = data.get('item_id')
        quantity = data.get('quantity', 1)
        
        # Check balance at source node with flexibility for healthcare nodes
        current_balance = blockchain.get_balance(from_node, item_id)
        
        if current_balance < quantity:
            # Get source node type
            from_node_obj = next((node for node in blockchain.nodes if node.node_id == from_node), None)
            
            # Allow transfers for certain node types or new items
            if from_node_obj and from_node_obj.node_type.value in ['warehouse', 'distributor', 'hospital']:
                # Healthcare nodes can create inventory for transfers
                return True
            else:
                # Check if this is a new item being introduced
                item_exists = any(
                    tx.data.get('item_id') == item_id
                    for block in blockchain.chain
                    for tx in block.transactions
                )
                if not item_exists:
                    # New item - allow the transfer to introduce it
                    return True
                else:
                    return False
            
        return True
        
    def _validate_validation_logic(self, transaction, blockchain) -> bool:
        """Validate validation-specific business logic"""
        data = transaction.data
        item_id = data.get('item_id')
        validator = data.get('validator')
        
        # Check if item exists in blockchain or pending transactions
        item_exists = any(
            tx.data.get('item_id') == item_id
            for block in blockchain.chain
            for tx in block.transactions
        )
        
        # Also check pending transactions for the item
        if not item_exists:
            item_exists = any(
                tx.data.get('item_id') == item_id
                for tx in blockchain.pending_transactions
            )
        
        # Allow validation even if item doesn't exist yet (for new items being introduced)
        if not item_exists:
            # This validation could be for a new item being introduced
            pass
            
        # Check validator authority (all nodes can validate for now)
        return True
        
    def _validate_security(self, transaction, blockchain) -> bool:
        """Validate security aspects of the transaction"""
        # Check for replay attacks (duplicate transaction IDs)
        existing_tx_ids = set()
        for block in blockchain.chain:
            for tx in block.transactions:
                existing_tx_ids.add(tx.transaction_id)
                
        if transaction.transaction_id in existing_tx_ids:
            return False
            
        # Check for double spending attempts
        if not self._check_double_spending(transaction, blockchain):
            return False
            
        # Validate transaction signature (simplified)
        # In a real implementation, this would verify cryptographic signatures
        if not hasattr(transaction, 'signature') or not transaction.signature:
            return False
            
        return True
        
    def _check_double_spending(self, transaction, blockchain) -> bool:
        """Check for double spending attempts"""
        data = transaction.data
        action = data.get('action')
        
        # Only check for actions that spend resources
        if action not in ['dispatch', 'transfer', 'emergency_dispatch', 'bulk_transfer']:
            return True
            
        item_id = data.get('item_id')
        quantity = data.get('quantity', 0)
        sender = transaction.sender
        
        # Check pending transactions for conflicts
        for pending_tx in blockchain.pending_transactions:
            if pending_tx.transaction_id == transaction.transaction_id:
                continue
                
            pending_data = pending_tx.data
            if (pending_data.get('action') in ['dispatch', 'transfer'] and
                pending_tx.sender == sender and
                pending_data.get('item_id') == item_id):
                
                # Check if combined quantity exceeds balance
                pending_quantity = pending_data.get('quantity', 0)
                current_balance = blockchain.get_balance(sender, item_id)
                
                if current_balance < quantity + pending_quantity:
                    return False
                    
        return True
        
    def get_validation_report(self, transaction, blockchain) -> Dict[str, Any]:
        """Generate detailed validation report for a transaction"""
        report = {
            'transaction_id': transaction.transaction_id,
            'valid': True,
            'errors': [],
            'warnings': [],
            'checks_performed': []
        }
        
        try:
            # Structure validation
            if not self._validate_transaction_structure(transaction):
                report['valid'] = False
                report['errors'].append("Invalid transaction structure")
            report['checks_performed'].append("Structure validation")
            
            # Action validation
            action = transaction.data.get('action')
            if action not in self.validation_rules:
                report['valid'] = False
                report['errors'].append(f"Unknown action: {action}")
            report['checks_performed'].append("Action validation")
            
            # Business logic validation
            if not self._validate_business_logic(transaction, blockchain):
                report['valid'] = False
                report['errors'].append("Business logic validation failed")
            report['checks_performed'].append("Business logic validation")
            
            # Security validation
            if not self._validate_security(transaction, blockchain):
                report['valid'] = False
                report['errors'].append("Security validation failed")
            report['checks_performed'].append("Security validation")
            
            # Add warnings for potential issues
            conflicts = blockchain.detect_conflicts(transaction)
            if conflicts:
                report['warnings'].extend(conflicts)
                
        except Exception as e:
            report['valid'] = False
            report['errors'].append(f"Validation exception: {str(e)}")
            
        return report
    
    def _validate_emergency_dispatch_logic(self, transaction, blockchain) -> bool:
        """Validate emergency dispatch specific business logic"""
        data = transaction.data
        sender = transaction.sender
        item_id = data.get('item_id')
        quantity = data.get('quantity', 0)
        destination = data.get('destination')
        priority = data.get('priority')
        
        # Emergency dispatches can bypass normal balance checks for critical situations
        if priority == 'critical':
            return True  # Critical emergencies bypass all balance checks
            
        # For high/urgent priority, allow some flexibility but still check reasonable limits
        sender_node = next((node for node in blockchain.nodes if node.node_id == sender), None)
        if sender_node and sender_node.node_type.value in ['warehouse', 'distributor', 'hospital']:
            return True  # These nodes can handle emergency dispatches
            
        return True
    
    def _validate_bulk_transfer_logic(self, transaction, blockchain) -> bool:
        """Validate bulk transfer specific business logic"""
        data = transaction.data
        from_node = data.get('from_node')
        to_node = data.get('to_node')
        item_id = data.get('item_id')
        quantity = data.get('quantity', 0)
        
        # Check balance for bulk transfers
        current_balance = blockchain.get_balance(from_node, item_id)
        
        # Allow bulk transfers if source is a warehouse/distributor or if balance is sufficient
        from_node_obj = next((node for node in blockchain.nodes if node.node_id == from_node), None)
        if from_node_obj and from_node_obj.node_type.value in ['warehouse', 'distributor']:
            return True  # Warehouses can create inventory for bulk operations
            
        if current_balance >= quantity:
            return True
            
        # Allow if this is the first transaction for this item (new item introduction)
        item_exists = any(
            tx.data.get('item_id') == item_id
            for block in blockchain.chain
            for tx in block.transactions
        )
        
        return not item_exists  # Allow if new item
    
    def _validate_temperature_track_logic(self, transaction, blockchain) -> bool:
        """Validate temperature tracking specific business logic"""
        data = transaction.data
        item_id = data.get('item_id')
        recorder = data.get('recorder')
        temperature = data.get('temperature')
        threshold_min = data.get('threshold_min')
        threshold_max = data.get('threshold_max')
        
        # Check if recorder node exists and has appropriate capabilities
        recorder_node = next((node for node in blockchain.nodes if node.node_id == recorder), None)
        if not recorder_node:
            return False
            
        # Temperature tracking can be done by any node type
        return True
