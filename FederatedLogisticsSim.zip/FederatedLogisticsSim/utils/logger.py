import logging
import os
from datetime import datetime
from typing import Optional, Dict, Any
import json

class BlockchainLogger:
    """Logger for blockchain operations and events"""
    
    def __init__(self, log_level: str = "INFO", log_file: Optional[str] = None):
        self.log_level = getattr(logging, log_level.upper())
        self.log_file = log_file or "blockchain.log"
        self.setup_logger()
        
    def setup_logger(self):
        """Setup logging configuration"""
        # Create logger
        self.logger = logging.getLogger('blockchain')
        self.logger.setLevel(self.log_level)
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # Create formatters
        detailed_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        simple_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(self.log_level)
        console_handler.setFormatter(simple_formatter)
        self.logger.addHandler(console_handler)
        
        # File handler (if log file specified)
        if self.log_file:
            try:
                file_handler = logging.FileHandler(self.log_file)
                file_handler.setLevel(self.log_level)
                file_handler.setFormatter(detailed_formatter)
                self.logger.addHandler(file_handler)
            except Exception as e:
                self.logger.warning(f"Could not create file handler: {e}")
                
    def log(self, message: str, level: str = "INFO", extra_data: Optional[Dict[str, Any]] = None):
        """Log a message with optional extra data"""
        log_method = getattr(self.logger, level.lower(), self.logger.info)
        
        if extra_data:
            log_method(f"{message} | Extra: {json.dumps(extra_data)}")
        else:
            log_method(message)
            
    def log_transaction(self, transaction_id: str, action: str, sender: str, 
                       status: str = "created", extra_data: Optional[Dict[str, Any]] = None):
        """Log transaction-related events"""
        message = f"Transaction {status}: {transaction_id} | Action: {action} | Sender: {sender}"
        self.log(message, "INFO", extra_data)
        
    def log_block(self, block_index: int, block_hash: str, transaction_count: int,
                  validator: str = "", extra_data: Optional[Dict[str, Any]] = None):
        """Log block-related events"""
        message = f"Block created: #{block_index} | Hash: {block_hash[:12]}... | Transactions: {transaction_count}"
        if validator:
            message += f" | Validator: {validator}"
        self.log(message, "INFO", extra_data)
        
    def log_consensus(self, round_number: int, validator: str, result: str,
                     extra_data: Optional[Dict[str, Any]] = None):
        """Log consensus-related events"""
        message = f"Consensus Round {round_number}: Validator {validator} | Result: {result}"
        self.log(message, "INFO", extra_data)
        
    def log_node_event(self, node_id: str, event: str, details: str = "",
                      extra_data: Optional[Dict[str, Any]] = None):
        """Log node-related events"""
        message = f"Node {node_id}: {event}"
        if details:
            message += f" | {details}"
        self.log(message, "INFO", extra_data)
        
    def log_validation(self, transaction_id: str, result: bool, errors: list = None,
                      extra_data: Optional[Dict[str, Any]] = None):
        """Log validation events"""
        status = "PASSED" if result else "FAILED"
        message = f"Validation {status}: {transaction_id}"
        
        if errors:
            message += f" | Errors: {', '.join(errors)}"
            
        level = "INFO" if result else "WARNING"
        self.log(message, level, extra_data)
        
    def log_error(self, error_message: str, exception: Optional[Exception] = None,
                  extra_data: Optional[Dict[str, Any]] = None):
        """Log error events"""
        message = f"Error: {error_message}"
        
        if exception:
            message += f" | Exception: {str(exception)}"
            
        self.log(message, "ERROR", extra_data)
        
    def log_security_event(self, event_type: str, severity: str, description: str,
                          source: str = "", extra_data: Optional[Dict[str, Any]] = None):
        """Log security-related events"""
        message = f"Security Event [{severity.upper()}]: {event_type} | {description}"
        if source:
            message += f" | Source: {source}"
            
        level = "WARNING" if severity.lower() in ["medium", "high"] else "INFO"
        self.log(message, level, extra_data)
        
    def log_performance(self, operation: str, duration: float, details: str = "",
                       extra_data: Optional[Dict[str, Any]] = None):
        """Log performance metrics"""
        message = f"Performance: {operation} took {duration:.3f}s"
        if details:
            message += f" | {details}"
            
        level = "WARNING" if duration > 5.0 else "INFO"  # Warn if operation takes > 5 seconds
        self.log(message, level, extra_data)
        
    def get_recent_logs(self, count: int = 50) -> list:
        """Get recent log entries from file"""
        if not self.log_file or not os.path.exists(self.log_file):
            return []
            
        try:
            with open(self.log_file, 'r') as f:
                lines = f.readlines()
                return lines[-count:] if len(lines) > count else lines
        except Exception as e:
            self.log_error(f"Could not read log file: {e}")
            return []
            
    def clear_logs(self):
        """Clear log file"""
        if self.log_file and os.path.exists(self.log_file):
            try:
                open(self.log_file, 'w').close()
                self.log("Log file cleared", "INFO")
            except Exception as e:
                self.log_error(f"Could not clear log file: {e}")

class AuditLogger(BlockchainLogger):
    """Specialized logger for audit trails"""
    
    def __init__(self, audit_file: str = "blockchain_audit.log"):
        super().__init__(log_file=audit_file)
        self.audit_trail = []
        
    def create_audit_entry(self, action: str, user: str, resource: str, 
                          result: str, details: Optional[Dict[str, Any]] = None) -> str:
        """Create standardized audit entry"""
        audit_entry = {
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'user': user,
            'resource': resource,
            'result': result,
            'details': details or {}
        }
        
        self.audit_trail.append(audit_entry)
        
        # Log to file
        audit_message = (f"AUDIT: {action} by {user} on {resource} - {result}")
        self.log(audit_message, "INFO", audit_entry)
        
        return json.dumps(audit_entry)
        
    def get_audit_trail(self, start_time: Optional[datetime] = None, 
                       end_time: Optional[datetime] = None) -> list:
        """Get audit trail for specified time period"""
        filtered_trail = self.audit_trail
        
        if start_time:
            filtered_trail = [
                entry for entry in filtered_trail 
                if datetime.fromisoformat(entry['timestamp']) >= start_time
            ]
            
        if end_time:
            filtered_trail = [
                entry for entry in filtered_trail 
                if datetime.fromisoformat(entry['timestamp']) <= end_time
            ]
            
        return filtered_trail
        
    def export_audit_trail(self, filename: str = None) -> str:
        """Export audit trail to file"""
        if not filename:
            filename = f"audit_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
        try:
            with open(filename, 'w') as f:
                json.dump(self.audit_trail, f, indent=2)
            
            self.log(f"Audit trail exported to {filename}", "INFO")
            return filename
        except Exception as e:
            self.log_error(f"Could not export audit trail: {e}")
            return ""
