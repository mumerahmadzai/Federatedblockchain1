import hashlib
import hmac
import secrets
from typing import Optional, Tuple
import json
from datetime import datetime

class SimpleCrypto:
    """Simplified cryptographic functions for blockchain simulation"""
    
    @staticmethod
    def generate_key_pair() -> Tuple[str, str]:
        """Generate a simple key pair for simulation"""
        private_key = secrets.token_hex(32)
        public_key = hashlib.sha256(private_key.encode()).hexdigest()
        return private_key, public_key
        
    @staticmethod
    def hash_data(data: str) -> str:
        """Create SHA-256 hash of data"""
        return hashlib.sha256(data.encode()).hexdigest()
        
    @staticmethod
    def create_merkle_root(data_list: list) -> str:
        """Create Merkle root from list of data"""
        if not data_list:
            return ""
            
        # Convert all data to strings and hash
        hashes = [SimpleCrypto.hash_data(str(data)) for data in data_list]
        
        while len(hashes) > 1:
            new_level = []
            for i in range(0, len(hashes), 2):
                if i + 1 < len(hashes):
                    combined = hashes[i] + hashes[i + 1]
                else:
                    combined = hashes[i] + hashes[i]
                new_level.append(SimpleCrypto.hash_data(combined))
            hashes = new_level
            
        return hashes[0] if hashes else ""

def sign_transaction(transaction_data: str, private_key: Optional[str] = None) -> str:
    """Sign transaction data (simplified for simulation)"""
    if private_key is None:
        private_key = "default_private_key_for_simulation"
        
    # Create HMAC signature
    signature = hmac.new(
        private_key.encode(),
        transaction_data.encode(),
        hashlib.sha256
    ).hexdigest()
    
    return signature

def verify_signature(transaction_data: str, signature: str, public_key: Optional[str] = None) -> bool:
    """Verify transaction signature (simplified)"""
    if public_key is None:
        # For simulation, derive from default private key
        private_key = "default_private_key_for_simulation"
        public_key = hashlib.sha256(private_key.encode()).hexdigest()
        
    # Recreate signature and compare
    expected_signature = hmac.new(
        "default_private_key_for_simulation".encode(),
        transaction_data.encode(),
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(signature, expected_signature)

def generate_transaction_id() -> str:
    """Generate unique transaction ID"""
    timestamp = str(int(datetime.now().timestamp() * 1000000))
    random_part = secrets.token_hex(16)
    return hashlib.sha256(f"{timestamp}{random_part}".encode()).hexdigest()[:32]

def encrypt_sensitive_data(data: str, key: Optional[str] = None) -> str:
    """Simple encryption for sensitive data (simulation only)"""
    if key is None:
        key = "default_encryption_key"
        
    # Simple XOR encryption for simulation
    encrypted = ""
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    
    for i, char in enumerate(data):
        key_char = key_hash[i % len(key_hash)]
        encrypted += chr(ord(char) ^ ord(key_char))
        
    # Return base64-like encoding
    import base64
    return base64.b64encode(encrypted.encode()).decode()

def decrypt_sensitive_data(encrypted_data: str, key: Optional[str] = None) -> str:
    """Simple decryption for sensitive data (simulation only)"""
    if key is None:
        key = "default_encryption_key"
        
    try:
        import base64
        encrypted = base64.b64decode(encrypted_data.encode()).decode()
        
        decrypted = ""
        key_hash = hashlib.sha256(key.encode()).hexdigest()
        
        for i, char in enumerate(encrypted):
            key_char = key_hash[i % len(key_hash)]
            decrypted += chr(ord(char) ^ ord(key_char))
            
        return decrypted
    except:
        return "Decryption failed"

def create_digital_fingerprint(data: dict) -> str:
    """Create digital fingerprint of transaction data"""
    # Sort keys for consistent hashing
    sorted_data = json.dumps(data, sort_keys=True)
    fingerprint = hashlib.sha256(sorted_data.encode()).hexdigest()
    return fingerprint

def validate_data_integrity(data: dict, fingerprint: str) -> bool:
    """Validate data integrity using fingerprint"""
    current_fingerprint = create_digital_fingerprint(data)
    return current_fingerprint == fingerprint

class BlockchainCrypto:
    """Blockchain-specific cryptographic operations"""
    
    def __init__(self):
        self.crypto = SimpleCrypto()
        
    def create_block_hash(self, block_data: dict) -> str:
        """Create hash for a block"""
        block_string = json.dumps(block_data, sort_keys=True)
        return self.crypto.hash_data(block_string)
        
    def validate_block_hash(self, block_data: dict, claimed_hash: str) -> bool:
        """Validate block hash"""
        calculated_hash = self.create_block_hash(block_data)
        return calculated_hash == claimed_hash
        
    def create_proof_of_work(self, block_data: dict, difficulty: int = 4) -> Tuple[str, int]:
        """Create proof of work (simplified)"""
        target = "0" * difficulty
        nonce = 0
        
        while True:
            block_data['nonce'] = nonce
            block_hash = self.create_block_hash(block_data)
            
            if block_hash.startswith(target):
                return block_hash, nonce
                
            nonce += 1
            
            # Prevent infinite loop in simulation
            if nonce > 100000:
                break
                
        return self.create_block_hash(block_data), nonce
        
    def validate_proof_of_work(self, block_data: dict, difficulty: int = 4) -> bool:
        """Validate proof of work"""
        target = "0" * difficulty
        block_hash = self.create_block_hash(block_data)
        return block_hash.startswith(target)
