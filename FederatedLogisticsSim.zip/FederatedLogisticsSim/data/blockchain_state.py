from typing import Dict, Any, List, Optional
from datetime import datetime
import json

class BlockchainState:
    """Manages the state of the blockchain simulation"""
    
    def __init__(self):
        self.blockchain = None  # type: ignore
        self.nodes: Dict[str, Any] = {}
        self.network_topology = None
        self.simulation_started = datetime.now()
        self.simulation_stats = {
            'total_transactions': 0,
            'successful_transactions': 0,
            'failed_transactions': 0,
            'blocks_mined': 0,
            'consensus_rounds': 0
        }
        self.active_sessions = {}
        self.system_alerts = []
        
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        if not self.blockchain:
            return {'status': 'not_initialized'}
            
        return {
            'status': 'active',
            'uptime': str(datetime.now() - self.simulation_started),
            'blockchain_height': len(self.blockchain.chain),
            'pending_transactions': len(self.blockchain.pending_transactions),
            'active_nodes': len(self.nodes),
            'validators': len(self.blockchain.consensus_mechanism.validators),
            'stats': self.simulation_stats,
            'alerts': len(self.system_alerts)
        }
        
    def update_stats(self, event_type: str, increment: int = 1):
        """Update simulation statistics"""
        if event_type in self.simulation_stats:
            self.simulation_stats[event_type] += increment
            
    def add_alert(self, alert_type: str, message: str, severity: str = 'info'):
        """Add system alert"""
        alert = {
            'timestamp': datetime.now().isoformat(),
            'type': alert_type,
            'message': message,
            'severity': severity
        }
        self.system_alerts.append(alert)
        
        # Keep only last 100 alerts
        if len(self.system_alerts) > 100:
            self.system_alerts = self.system_alerts[-100:]
            
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        if not self.blockchain:
            return {}
            
        total_transactions = sum(len(block.transactions) for block in self.blockchain.chain)
        uptime_hours = (datetime.now() - self.simulation_started).total_seconds() / 3600
        
        return {
            'transactions_per_hour': total_transactions / uptime_hours if uptime_hours > 0 else 0,
            'blocks_per_hour': len(self.blockchain.chain) / uptime_hours if uptime_hours > 0 else 0,
            'average_block_size': total_transactions / len(self.blockchain.chain) if len(self.blockchain.chain) > 0 else 0,
            'consensus_efficiency': (self.simulation_stats['successful_transactions'] / 
                                   max(1, self.simulation_stats['total_transactions'])) * 100,
            'network_utilization': len(self.blockchain.pending_transactions) / 100 * 100  # Assuming 100 is max capacity
        }
        
    def get_network_health(self) -> Dict[str, Any]:
        """Get network health indicators"""
        if not self.blockchain:
            return {'status': 'unhealthy', 'score': 0}
            
        health_score = 100
        issues = []
        
        # Check validator count
        validator_count = len(self.blockchain.consensus_mechanism.validators)
        if validator_count < 2:
            health_score -= 30
            issues.append("Insufficient validators")
            
        # Check node distribution
        node_types = {}
        for node in self.nodes.values():
            node_type = node.node_type.value
            node_types[node_type] = node_types.get(node_type, 0) + 1
            
        if len(node_types) < 2:
            health_score -= 20
            issues.append("Low node type diversity")
            
        # Check pending transaction backlog
        if len(self.blockchain.pending_transactions) > 50:
            health_score -= 25
            issues.append("High transaction backlog")
            
        # Check chain validity
        if not self.blockchain.validate_chain():
            health_score -= 50
            issues.append("Chain integrity compromised")
            
        status = "healthy" if health_score > 80 else "degraded" if health_score > 50 else "unhealthy"
        
        return {
            'status': status,
            'score': max(0, health_score),
            'issues': issues,
            'validator_count': validator_count,
            'node_diversity': len(node_types),
            'pending_transactions': len(self.blockchain.pending_transactions)
        }
        
    def export_state(self) -> Dict[str, Any]:
        """Export current blockchain state"""
        if not self.blockchain:
            return {}
            
        return {
            'export_timestamp': datetime.now().isoformat(),
            'simulation_started': self.simulation_started.isoformat(),
            'system_status': self.get_system_status(),
            'performance_metrics': self.get_performance_metrics(),
            'network_health': self.get_network_health(),
            'blockchain_data': {
                'chain_length': len(self.blockchain.chain),
                'total_transactions': sum(len(block.transactions) for block in self.blockchain.chain),
                'genesis_hash': self.blockchain.chain[0].hash if self.blockchain.chain else None,
                'latest_hash': self.blockchain.chain[-1].hash if self.blockchain.chain else None
            },
            'node_summary': {
                'total_nodes': len(self.nodes),
                'node_types': {
                    node_type: sum(1 for node in self.nodes.values() if node.node_type.value == node_type)
                    for node_type in set(node.node_type.value for node in self.nodes.values())
                }
            },
            'consensus_info': self.blockchain.consensus_mechanism.get_consensus_state(),
            'recent_alerts': self.system_alerts[-10:] if self.system_alerts else []
        }
        
    def reset_simulation(self):
        """Reset simulation state"""
        self.blockchain = None
        self.nodes = {}
        self.network_topology = None
        self.simulation_started = datetime.now()
        self.simulation_stats = {
            'total_transactions': 0,
            'successful_transactions': 0,
            'failed_transactions': 0,
            'blocks_mined': 0,
            'consensus_rounds': 0
        }
        self.active_sessions = {}
        self.system_alerts = []
        
    def get_transaction_analytics(self) -> Dict[str, Any]:
        """Get detailed transaction analytics"""
        if not self.blockchain:
            return {}
            
        analytics = {
            'total_transactions': 0,
            'action_distribution': {},
            'node_activity': {},
            'hourly_distribution': {},
            'success_rate': 0,
            'average_block_time': 0
        }
        
        block_times = []
        
        for i, block in enumerate(self.blockchain.chain):
            if i > 0:  # Skip genesis block
                prev_block = self.blockchain.chain[i-1]
                block_time = (block.timestamp - prev_block.timestamp).total_seconds()
                block_times.append(block_time)
            
            for tx in block.transactions:
                analytics['total_transactions'] += 1
                
                # Action distribution
                action = tx.data.get('action', 'unknown')
                analytics['action_distribution'][action] = analytics['action_distribution'].get(action, 0) + 1
                
                # Node activity
                sender = tx.sender
                analytics['node_activity'][sender] = analytics['node_activity'].get(sender, 0) + 1
                
                # Hourly distribution
                hour = tx.timestamp.hour
                analytics['hourly_distribution'][hour] = analytics['hourly_distribution'].get(hour, 0) + 1
        
        # Calculate averages
        if block_times:
            analytics['average_block_time'] = sum(block_times) / len(block_times)
            
        if analytics['total_transactions'] > 0:
            analytics['success_rate'] = (analytics['total_transactions'] / 
                                       max(1, analytics['total_transactions'] + len(self.system_alerts))) * 100
        
        return analytics
