"""
Demo script to create realistic blockchain transactions for AI analysis
"""
import sys
import os
sys.path.append('.')

from blockchain.core import FederatedBlockchain
from blockchain.nodes import HealthcareNode, NodeType
from datetime import datetime, timedelta
import time

def create_demo_data():
    """Create realistic blockchain data for AI analysis"""
    
    # Initialize blockchain
    blockchain = FederatedBlockchain()
    
    # Add nodes
    hospital_a = HealthcareNode("Hospital_A", NodeType.HOSPITAL, "New York Medical Center", "New York")
    hospital_b = HealthcareNode("Hospital_B", NodeType.HOSPITAL, "Central General Hospital", "Chicago") 
    warehouse_1 = HealthcareNode("Warehouse_1", NodeType.WAREHOUSE, "Medical Supply Depot", "Dallas")
    clinic_c = HealthcareNode("Clinic_C", NodeType.CLINIC, "Community Health Clinic", "Boston")
    
    # Add initial inventory to warehouse
    warehouse_1.update_inventory("MED_001", 1000)
    warehouse_1.update_inventory("MED_002", 500)
    warehouse_1.update_inventory("VAC_001", 200)
    
    blockchain.add_node(hospital_a)
    blockchain.add_node(hospital_b)
    blockchain.add_node(warehouse_1)
    blockchain.add_node(clinic_c)
    
    blockchain.set_validators(["Hospital_A", "Warehouse_1"])
    
    # Create realistic transactions
    transactions = [
        # Warehouse distributing to hospitals
        {
            "sender": "Warehouse_1",
            "data": {
                "action": "dispatch",
                "item_id": "MED_001", 
                "quantity": 100,
                "destination": "Hospital_A",
                "priority": "normal"
            }
        },
        {
            "sender": "Warehouse_1", 
            "data": {
                "action": "dispatch",
                "item_id": "MED_002",
                "quantity": 50,
                "destination": "Hospital_B", 
                "priority": "normal"
            }
        },
        # Emergency dispatch
        {
            "sender": "Warehouse_1",
            "data": {
                "action": "emergency_dispatch",
                "item_id": "VAC_001",
                "quantity": 25,
                "destination": "Clinic_C",
                "priority": "critical"
            }
        },
        # Hospitals receiving supplies
        {
            "sender": "Hospital_A",
            "data": {
                "action": "receive",
                "item_id": "MED_001",
                "quantity": 100,
                "source": "Warehouse_1"
            }
        },
        # Temperature monitoring
        {
            "sender": "Warehouse_1",
            "data": {
                "action": "temperature_track",
                "item_id": "VAC_001",
                "temperature": 4.2,
                "threshold_min": 2.0,
                "threshold_max": 8.0,
                "location": "Cold Storage Unit A"
            }
        }
    ]
    
    # Add transactions to blockchain
    for tx_data in transactions:
        try:
            # Update inventory before transaction
            if tx_data["data"]["action"] == "dispatch":
                sender_node = blockchain.nodes[tx_data["sender"]]
                item_id = tx_data["data"]["item_id"]
                quantity = tx_data["data"]["quantity"]
                
                # Ensure sender has inventory
                if sender_node.get_inventory_level(item_id) >= quantity:
                    sender_node.update_inventory(item_id, -quantity)
                    
                    # Add to destination
                    dest = tx_data["data"]["destination"]
                    if dest in blockchain.nodes:
                        blockchain.nodes[dest].update_inventory(item_id, quantity)
            
            # Create transaction
            transaction = blockchain.create_transaction(
                sender=tx_data["sender"],
                data=tx_data["data"]
            )
            
            # Add to pending pool
            if blockchain.add_pending_transaction(transaction):
                print(f"✅ Transaction added: {tx_data['data']['action']}")
                
                # Mine block
                if blockchain.consensus_mechanism.propose_block(blockchain):
                    print(f"⛏️ Block mined successfully")
            
            time.sleep(0.1)  # Small delay between transactions
            
        except Exception as e:
            print(f"❌ Error creating transaction: {e}")
    
    print(f"\n📊 Demo blockchain created:")
    print(f"• Chain length: {len(blockchain.chain)}")
    print(f"• Total transactions: {sum(len(block.transactions) for block in blockchain.chain)}")
    print(f"• Active nodes: {len(blockchain.nodes)}")
    
    return blockchain

if __name__ == "__main__":
    create_demo_data()