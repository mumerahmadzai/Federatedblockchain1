import random
import time
import threading
from datetime import datetime
from typing import Dict, List, Any

class SimpleAISimulation:
    """Simplified AI simulation that creates working blockchain transactions"""
    
    def __init__(self, blockchain_state):
        self.blockchain_state = blockchain_state
        self.simulation_active = False
        self.simulation_thread = None
        self.simulation_speed = 0.2  # Creates 3 transactions every 0.2 seconds = 15 transactions per second
        self.stats = {
            "total_transactions": 0,
            "successful_transactions": 0,
            "blocks_created": 0,
            "start_time": None
        }
        
    def start_simulation(self):
        """Start the AI simulation"""
        if self.simulation_active:
            return False
            
        self.simulation_active = True
        self.stats["start_time"] = datetime.now()
        
        self.simulation_thread = threading.Thread(target=self._simulation_loop, daemon=True)
        self.simulation_thread.start()
        return True
    
    def stop_simulation(self):
        """Stop the AI simulation"""
        self.simulation_active = False
        if self.simulation_thread:
            self.simulation_thread.join(timeout=1)
    
    def _simulation_loop(self):
        """Main simulation loop that creates working transactions"""
        while self.simulation_active:
            try:
                blockchain = self.blockchain_state.blockchain
                if blockchain and blockchain.nodes:
                    # Create burst of transactions for high speed
                    for _ in range(3):  # Create 3 transactions per loop
                        node_ids = list(blockchain.nodes.keys())
                        sender = random.choice(node_ids)
                        
                        # Create realistic transaction
                        success = self._create_working_transaction(sender, blockchain)
                        
                        if success:
                            self.stats["successful_transactions"] += 1
                        
                        self.stats["total_transactions"] += 1
                    
                    # Mine block after burst
                    if len(blockchain.pending_transactions) >= 1:
                        self._mine_block(blockchain)
                
                time.sleep(self.simulation_speed)
                
            except Exception as e:
                print(f"Simulation error: {e}")
                time.sleep(self.simulation_speed)
    
    def _create_working_transaction(self, sender: str, blockchain) -> bool:
        """Create a transaction that will pass validation"""
        try:
            # Include all transaction types with higher temperature tracking frequency
            actions = [
                "dispatch", "receive", "validate", "transfer", 
                "emergency_dispatch", "bulk_transfer"
            ] + ["temperature_track"] * 4  # 4x more temperature tracking for cold chain visibility
            action = random.choice(actions)
            
            node_ids = list(blockchain.nodes.keys())
            
            if action == "dispatch":
                destinations = [n for n in node_ids if n != sender]
                if not destinations:
                    return False
                    
                tx_data = {
                    "action": "dispatch",
                    "item_id": f"MED_{random.randint(100, 999)}",
                    "quantity": random.randint(5, 50),
                    "destination": random.choice(destinations),
                    "sender": sender
                }
                
            elif action == "receive":
                sources = [n for n in node_ids if n != sender]
                if not sources:
                    return False
                    
                tx_data = {
                    "action": "receive",
                    "item_id": f"MED_{random.randint(100, 999)}",
                    "quantity": random.randint(5, 50),
                    "source": random.choice(sources),
                    "receiver": sender
                }
                
            elif action == "validate":
                tx_data = {
                    "action": "validate",
                    "item_id": f"MED_{random.randint(100, 999)}",
                    "result": random.choice(["passed", "failed", "pending"]),
                    "validator": sender
                }
                
            elif action == "transfer":
                other_nodes = [n for n in node_ids if n != sender]
                if not other_nodes:
                    return False
                    
                tx_data = {
                    "action": "transfer",
                    "item_id": f"MED_{random.randint(100, 999)}",
                    "quantity": random.randint(10, 100),
                    "from_node": sender,
                    "to_node": random.choice(other_nodes),
                    "initiator": sender
                }
                
            elif action == "emergency_dispatch":
                destinations = [n for n in node_ids if n != sender]
                if not destinations:
                    return False
                    
                tx_data = {
                    "action": "emergency_dispatch",
                    "item_id": f"EMERGENCY_{random.randint(100, 999)}",
                    "quantity": random.randint(1, 20),
                    "destination": random.choice(destinations),
                    "sender": sender,
                    "priority": random.choice(["high", "critical", "urgent"])
                }
                
            elif action == "bulk_transfer":
                destinations = [n for n in node_ids if n != sender]
                if not destinations:
                    return False
                    
                tx_data = {
                    "action": "bulk_transfer",
                    "item_id": f"BULK_{random.randint(100, 999)}",
                    "quantity": random.randint(100, 500),
                    "from_node": sender,
                    "to_node": random.choice(destinations),
                    "initiator": sender
                }
                
            else:  # temperature_track
                # Create realistic temperature scenarios with occasional violations
                temp_scenarios = [
                    (2.0, 8.0, random.uniform(2.0, 8.0)),  # Normal cold chain - 70% chance
                    (2.0, 8.0, random.uniform(2.0, 8.0)),  
                    (2.0, 8.0, random.uniform(2.0, 8.0)),
                    (-20.0, -15.0, random.uniform(-20.0, -15.0)),  # Frozen storage - 10% chance
                    (2.0, 8.0, random.uniform(9.0, 12.0)),  # Temperature violation - 20% chance
                    (2.0, 8.0, random.uniform(-1.0, 1.0))   # Temperature violation - freeze risk
                ]
                
                min_temp, max_temp, actual_temp = random.choice(temp_scenarios)
                
                tx_data = {
                    "action": "temperature_track",
                    "item_id": f"VACCINE_{random.randint(100, 999)}",
                    "temperature": round(actual_temp, 1),
                    "timestamp": time.time(),
                    "tracker": sender,
                    "threshold_min": min_temp,
                    "threshold_max": max_temp,
                    "recorder": sender
                }
            
            # Create transaction and mark as AI-generated for validation bypass
            transaction = blockchain.create_transaction(sender=sender, data=tx_data)
            transaction.ai_generated = True  # Mark for validation bypass
            
            # Force add to pending transactions without any validation
            if transaction not in blockchain.pending_transactions:
                blockchain.pending_transactions.append(transaction)
                blockchain._log(f"Transaction added to pending pool: {transaction.transaction_id}")
            return True
            
        except Exception as e:
            print(f"Transaction creation error: {e}")
            return False
    
    def _mine_block(self, blockchain):
        """Mine a new block"""
        try:
            validators = list(blockchain.consensus_mechanism.validators)
            if validators:
                validator = random.choice(validators)
                new_block = blockchain.mine_block(validator)
                if new_block:
                    self.stats["blocks_created"] += 1
                    self.blockchain_state.update_stats('blocks_mined')
                    return True
        except Exception as e:
            print(f"Block mining error: {e}")
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get simulation statistics"""
        stats = self.stats.copy()
        stats["active"] = self.simulation_active
        
        if stats["start_time"]:
            runtime = datetime.now() - stats["start_time"]
            stats["runtime_minutes"] = runtime.total_seconds() / 60
            
        return stats