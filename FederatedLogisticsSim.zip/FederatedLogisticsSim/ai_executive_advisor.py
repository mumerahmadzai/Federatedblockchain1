"""
AI Executive Advisor for Healthcare Blockchain Platform
Provides intelligent decision support and strategic recommendations
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import numpy as np
from dataclasses import dataclass
from openai import OpenAI

@dataclass
class SupplyChainInsight:
    """Represents an AI-generated insight about the supply chain"""
    category: str
    priority: str  # "critical", "high", "medium", "low"
    title: str
    description: str
    recommendation: str
    confidence: float
    data_points: List[str]
    estimated_impact: str

class AIExecutiveAdvisor:
    """AI-powered executive decision support system"""
    
    def __init__(self):
        self.openai_client = None
        self.initialize_ai()
        
    def initialize_ai(self):
        """Initialize OpenAI client if API key is available"""
        api_key = os.environ.get("OPENAI_API_KEY")
        if api_key:
            self.openai_client = OpenAI(api_key=api_key)
    
    def analyze_supply_chain_performance(self, blockchain_data: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Analyze blockchain data and generate executive insights"""
        insights = []
        
        # Extract metrics from blockchain data
        metrics = self._extract_key_metrics(blockchain_data)
        
        # Generate different types of insights
        insights.extend(self._analyze_efficiency_patterns(metrics))
        insights.extend(self._assess_supply_risks(metrics))
        insights.extend(self._identify_optimization_opportunities(metrics))
        insights.extend(self._evaluate_network_health(metrics))
        
        # Use AI to enhance insights if available
        if self.openai_client:
            insights = self._enhance_with_ai_analysis(insights, metrics)
        
        # Sort by priority and confidence
        insights.sort(key=lambda x: (
            {"critical": 4, "high": 3, "medium": 2, "low": 1}[x.priority],
            x.confidence
        ), reverse=True)
        
        return insights[:8]  # Return top 8 insights
    
    def _extract_key_metrics(self, blockchain_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract key performance metrics from blockchain data"""
        chain = blockchain_data.get('chain', [])
        nodes = blockchain_data.get('nodes', {})
        
        if len(chain) <= 1:
            return {}
        
        # Transaction analysis
        total_transactions = sum(len(block.get('transactions', [])) for block in chain[1:])
        recent_blocks = chain[-10:] if len(chain) > 10 else chain[1:]
        recent_transactions = sum(len(block.get('transactions', [])) for block in recent_blocks)
        
        # Node performance
        node_activity = {}
        transaction_types = {}
        hourly_volume = {}
        
        for block in chain[1:]:
            block_time = block.get('timestamp', datetime.now())
            hour_key = block_time.hour if hasattr(block_time, 'hour') else 12
            
            for tx in block.get('transactions', []):
                sender = tx.get('sender', 'unknown')
                action = tx.get('data', {}).get('action', 'unknown')
                
                node_activity[sender] = node_activity.get(sender, 0) + 1
                transaction_types[action] = transaction_types.get(action, 0) + 1
                hourly_volume[hour_key] = hourly_volume.get(hour_key, 0) + 1
        
        # Calculate efficiency metrics
        avg_block_size = total_transactions / max(len(chain) - 1, 1)
        peak_hour_volume = max(hourly_volume.values()) if hourly_volume else 0
        most_active_node = max(node_activity.items(), key=lambda x: x[1]) if node_activity else ("none", 0)
        
        return {
            'total_transactions': total_transactions,
            'recent_transactions': recent_transactions,
            'avg_block_size': avg_block_size,
            'node_activity': node_activity,
            'transaction_types': transaction_types,
            'hourly_volume': hourly_volume,
            'peak_hour_volume': peak_hour_volume,
            'most_active_node': most_active_node,
            'network_nodes': len(nodes),
            'chain_length': len(chain)
        }
    
    def _analyze_efficiency_patterns(self, metrics: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Analyze operational efficiency patterns"""
        insights = []
        
        if not metrics:
            return insights
        
        # Transaction throughput analysis
        recent_tx = metrics.get('recent_transactions', 0)
        total_tx = metrics.get('total_transactions', 0)
        
        if total_tx > 0:
            recent_ratio = recent_tx / total_tx
            
            if recent_ratio > 0.4:  # High recent activity
                insights.append(SupplyChainInsight(
                    category="Operational Efficiency",
                    priority="high",
                    title="Increasing Transaction Volume Detected",
                    description=f"Recent transaction volume represents {recent_ratio:.1%} of total network activity, indicating accelerating supply chain operations.",
                    recommendation="Consider scaling infrastructure capacity and monitoring node performance to maintain optimal throughput.",
                    confidence=0.85,
                    data_points=[f"{recent_tx} recent transactions", f"{total_tx} total transactions"],
                    estimated_impact="15-25% improvement in processing efficiency"
                ))
        
        # Node utilization analysis
        node_activity = metrics.get('node_activity', {})
        if len(node_activity) > 1:
            activities = list(node_activity.values())
            avg_activity = np.mean(activities)
            std_activity = np.std(activities)
            
            if std_activity > avg_activity * 0.5:  # High variation
                insights.append(SupplyChainInsight(
                    category="Resource Optimization",
                    priority="medium",
                    title="Uneven Node Utilization Pattern",
                    description=f"Node activity varies significantly (σ={std_activity:.1f}, μ={avg_activity:.1f}), suggesting load imbalance.",
                    recommendation="Implement load balancing strategies and consider redistributing transaction workload across underutilized nodes.",
                    confidence=0.78,
                    data_points=[f"Activity std dev: {std_activity:.1f}", f"Average activity: {avg_activity:.1f}"],
                    estimated_impact="10-20% efficiency gain through load balancing"
                ))
        
        return insights
    
    def _assess_supply_risks(self, metrics: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Assess supply chain risks and vulnerabilities"""
        insights = []
        
        if not metrics:
            return insights
        
        # Single point of failure analysis
        most_active_node, max_activity = metrics.get('most_active_node', ("none", 0))
        total_activity = sum(metrics.get('node_activity', {}).values())
        
        if total_activity > 0 and max_activity / total_activity > 0.4:
            insights.append(SupplyChainInsight(
                category="Risk Management",
                priority="critical",
                title="High Dependency on Single Node",
                description=f"Node {most_active_node} handles {max_activity/total_activity:.1%} of all transactions, creating a critical dependency.",
                recommendation="Immediately diversify transaction processing across multiple nodes and implement redundancy measures to reduce single-point-of-failure risk.",
                confidence=0.92,
                data_points=[f"{most_active_node}: {max_activity} transactions", f"Total network activity: {total_activity}"],
                estimated_impact="Critical: Potential 40-60% service disruption if node fails"
            ))
        
        # Transaction type concentration
        tx_types = metrics.get('transaction_types', {})
        if tx_types:
            emergency_ratio = tx_types.get('emergency_dispatch', 0) / sum(tx_types.values())
            
            if emergency_ratio > 0.15:  # High emergency ratio
                insights.append(SupplyChainInsight(
                    category="Supply Chain Risk",
                    priority="high",
                    title="Elevated Emergency Transaction Rate",
                    description=f"Emergency dispatches account for {emergency_ratio:.1%} of transactions, indicating potential supply chain stress.",
                    recommendation="Investigate root causes of emergency situations and implement proactive inventory management to reduce urgent demands.",
                    confidence=0.83,
                    data_points=[f"Emergency transactions: {emergency_ratio:.1%}", "Normal operations should be <10%"],
                    estimated_impact="20-30% reduction in emergency costs through proactive planning"
                ))
        
        return insights
    
    def _identify_optimization_opportunities(self, metrics: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Identify opportunities for optimization"""
        insights = []
        
        if not metrics:
            return insights
        
        # Peak hour analysis
        hourly_volume = metrics.get('hourly_volume', {})
        if hourly_volume:
            peak_volume = max(hourly_volume.values())
            avg_volume = np.mean(list(hourly_volume.values()))
            
            if peak_volume > avg_volume * 2:  # High peak-to-average ratio
                peak_hours = [h for h, v in hourly_volume.items() if v == peak_volume]
                insights.append(SupplyChainInsight(
                    category="Process Optimization",
                    priority="medium",
                    title="Significant Peak Hour Congestion",
                    description=f"Peak hour volume ({peak_volume}) is {peak_volume/avg_volume:.1f}x average, occurring around hour {peak_hours[0]}.",
                    recommendation="Implement time-based transaction scheduling and consider incentivizing off-peak operations to smooth demand distribution.",
                    confidence=0.76,
                    data_points=[f"Peak volume: {peak_volume}", f"Average volume: {avg_volume:.1f}"],
                    estimated_impact="15-25% improvement in processing efficiency during peak hours"
                ))
        
        # Block size optimization
        avg_block_size = metrics.get('avg_block_size', 0)
        if avg_block_size < 2:  # Low block utilization
            insights.append(SupplyChainInsight(
                category="Technical Optimization",
                priority="low",
                title="Low Block Utilization Efficiency",
                description=f"Average block size of {avg_block_size:.1f} transactions suggests suboptimal batching.",
                recommendation="Optimize transaction batching algorithms and consider adjusting block timing to improve throughput efficiency.",
                confidence=0.72,
                data_points=[f"Average block size: {avg_block_size:.1f}", "Optimal range: 3-5 transactions/block"],
                estimated_impact="5-10% improvement in network throughput"
            ))
        
        return insights
    
    def _evaluate_network_health(self, metrics: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Evaluate overall network health and growth"""
        insights = []
        
        if not metrics:
            return insights
        
        # Network growth analysis
        total_tx = metrics.get('total_transactions', 0)
        chain_length = metrics.get('chain_length', 0)
        
        if chain_length > 10:
            tx_per_block = total_tx / (chain_length - 1)
            
            if tx_per_block > 2.5:  # Healthy transaction rate
                insights.append(SupplyChainInsight(
                    category="Network Health",
                    priority="low",
                    title="Strong Network Transaction Activity",
                    description=f"Network maintains healthy transaction rate of {tx_per_block:.1f} transactions per block across {chain_length} blocks.",
                    recommendation="Continue current operational practices while monitoring for scalability needs as network grows.",
                    confidence=0.81,
                    data_points=[f"Transaction rate: {tx_per_block:.1f}/block", f"Network blocks: {chain_length}"],
                    estimated_impact="Sustained operational efficiency"
                ))
        
        return insights
    
    def _enhance_with_ai_analysis(self, insights: List[SupplyChainInsight], metrics: Dict[str, Any]) -> List[SupplyChainInsight]:
        """Enhance insights using AI analysis"""
        if not self.openai_client:
            return insights
        
        try:
            # Prepare context for AI analysis
            context = {
                "insights_count": len(insights),
                "critical_issues": len([i for i in insights if i.priority == "critical"]),
                "high_priority": len([i for i in insights if i.priority == "high"]),
                "total_transactions": metrics.get('total_transactions', 0),
                "network_nodes": metrics.get('network_nodes', 0),
                "most_active_node": metrics.get('most_active_node', ["unknown", 0])[0]
            }
            
            # Generate AI-enhanced strategic recommendation
            prompt = f"""
            As a healthcare supply chain executive advisor, analyze this blockchain network data and provide one strategic insight:
            
            Current Analysis: {len(insights)} insights identified
            - Critical issues: {context['critical_issues']}
            - High priority items: {context['high_priority']}
            - Total transactions: {context['total_transactions']}
            - Network nodes: {context['network_nodes']}
            - Most active node: {context['most_active_node']}
            
            Provide a strategic executive recommendation in JSON format:
            {{
                "title": "Strategic insight title",
                "description": "Executive-level analysis of the situation",
                "recommendation": "Specific actionable recommendation",
                "confidence": 0.85,
                "estimated_impact": "Business impact description"
            }}
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
                messages=[
                    {"role": "system", "content": "You are an expert healthcare supply chain consultant providing strategic insights. Respond only with valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                max_tokens=300,
                temperature=0.3
            )
            
            ai_insight = json.loads(response.choices[0].message.content)
            
            # Add AI-generated strategic insight
            insights.append(SupplyChainInsight(
                category="Strategic Analysis",
                priority="high",
                title=ai_insight.get("title", "AI Strategic Recommendation"),
                description=ai_insight.get("description", "AI-generated strategic analysis"),
                recommendation=ai_insight.get("recommendation", "AI-recommended action"),
                confidence=float(ai_insight.get("confidence", 0.85)),
                data_points=["AI-powered analysis", "Strategic assessment"],
                estimated_impact=ai_insight.get("estimated_impact", "Strategic business impact")
            ))
            
        except Exception as e:
            # Fallback: Add a strategic insight based on rule-based analysis
            if context['critical_issues'] > 0:
                insights.append(SupplyChainInsight(
                    category="Strategic Analysis",
                    priority="critical",
                    title="Executive Action Required",
                    description=f"Analysis identified {context['critical_issues']} critical issues requiring immediate executive attention.",
                    recommendation="Convene emergency operations meeting to address critical supply chain vulnerabilities and implement immediate mitigation measures.",
                    confidence=0.90,
                    data_points=[f"{context['critical_issues']} critical issues", "Executive intervention required"],
                    estimated_impact="Prevent potential supply chain disruption"
                ))
        
        return insights
    
    def generate_executive_summary(self, insights: List[SupplyChainInsight]) -> Dict[str, Any]:
        """Generate executive dashboard summary"""
        critical_count = len([i for i in insights if i.priority == "critical"])
        high_count = len([i for i in insights if i.priority == "high"])
        
        # Calculate overall health score
        total_insights = len(insights)
        if total_insights == 0:
            health_score = 85  # Default good score
        else:
            penalty = (critical_count * 20) + (high_count * 10)
            health_score = max(10, 100 - penalty)
        
        # Determine health status
        if health_score >= 80:
            health_status = "Excellent"
            health_color = "#059669"
        elif health_score >= 60:
            health_status = "Good"
            health_color = "#d97706"
        elif health_score >= 40:
            health_status = "Attention Required"
            health_color = "#dc2626"
        else:
            health_status = "Critical"
            health_color = "#991b1b"
        
        return {
            "health_score": health_score,
            "health_status": health_status,
            "health_color": health_color,
            "critical_issues": critical_count,
            "high_priority": high_count,
            "total_insights": total_insights,
            "top_recommendations": [i.recommendation for i in insights[:3]]
        }